library ieee;
use ieee.std_logic_1164.all;
 
entity testbench_full_adder is
end testbench_full_adder;
 
architecture behavior of testbench_full_adder is
	
	-- component declaration for the unit under test (uut)
	
	component full_adder
		port(
			A 	: in std_logic;
			B 	: in std_logic;
			Cin : in std_logic;
			S 	: out std_logic;
			Cout: out std_logic
		);
	end component;
	
	--Inputs
	signal A 	: std_logic := '0';
	signal B 	: std_logic := '0';
	signal Cin 	: std_logic := '0';
	
	--Outputs
	signal S 	: std_logic;
	signal Cout : std_logic;
	
begin
	
	-- Instantiate the Unit Under Test (UUT)
	uut: full_adder 
		port map (
			A => A,
			B => B,
			Cin => Cin,
			S => S,
			Cout => Cout
		);
	

	process
	begin
	-- hold reset state for 100 ns.
	wait for 100 ns;
	
	--Valeurs des sorties attendues :
	--	Cout = 0
	--	S = 0
	
	assert (Cout= '1' or s = '1') 
	   report "output valid when A=0 B=0 and Cin=0" severity note;
	assert (Cout= '0' and s = '0') 
	   report "error when A=0 B=0 and Cin=0" severity warning;
	wait for 5 ns;
	A <= '1';
	B <= '0';
	Cin <= '0';
	wait for 5 ns;	--Valeurs des sorties attendues :
	--	Cout = 0
	--	S = 1
	assert (Cout= '1' or s='0') 
	   report "output valid when A=1 B=0 and Cin=0" severity note;
	assert (Cout= '0' and s = '1') 
	   report "error when A=1 B=0 and Cin=0" severity warning;
	wait for 5 ns;	
	A <= '0';
	B <= '1';
	Cin <= '0';
	wait for 5 ns;	
	--Valeurs des sorties attendues :
	--	Cout = 0
	--	S = 0
	assert (Cout= '1' or s='1') 
	   report "output valid  when A=0 B=1 and Cin=0" severity note;
	assert (Cout= '0' and s='0') 
	   report "error when A=0 B=1 and Cin=0" severity warning;
	wait for 5 ns;	
	A <= '1';
	B <= '1';
	Cin <= '0';
	wait for 5 ns;	
	--Valeurs des sorties attendues :
	--	Cout = 1
	--	S = 0
	assert (Cout = '0' or s = '1') 
	   report "output valid when A=1 B=1 and Cin=0" severity note;
	assert (Cout = '1' and s = '0') 
	   report "error when A=1 B=1 and Cin=0" severity warning;
	wait for 5 ns;
	A <= '0';
	B <= '0';
	Cin <= '1';
	wait for 5 ns;	
	--Valeurs des sorties attendues :
	--	Cout = 0
	--	S = 1
	assert (Cout = '1' or s = '0') 
	   report "output valid  when A=0 B=0 and Cin=1" severity note;
	assert (Cout = '0' and s = '1') 
	   report "error when A=0 B=0 and Cin=1" severity warning;
	wait for 5 ns;	
	A <= '1';
	B <= '0';
	Cin <= '1';
	wait for 5 ns;
	
	--Valeurs des sorties attendues :
	--	Cout = 1
	--	S = 0
	
	assert (Cout = '0' or s = '1' ) 
	   report "output valid when A=1 B=0 and Cin=1" severity note;
	assert (Cout = '1' and s = '0' ) 
	   report "error when A=1 B=0 and Cin=1" severity warning;
	wait for 5 ns;	
	A <= '0';
	B <= '1';
	Cin <= '1';
	wait for 5 ns;
	
	--Valeurs des sorties attendues :
	--	Cout = 1
	--	S = 0
	assert (Cout = '0' or s = '1') 
	   report "output valid when A=0 B=1 and Cin=1" severity note;
	assert (Cout = '1' and s = '0') 
	   report "error when A=0 B=1 and Cin=1" severity warning;
	wait for 5 ns;
	A <= '1';
	B <= '1';
	Cin <= '1';
	wait for 5 ns;
	
	--Valeurs des sorties attendues :
	--	Cout = 1
	--	S = 1
	assert (Cout = '0' or s = '0') 
	   report "output valid when A=1 B=1 and Cin=1" severity note;
	assert (Cout = '1' and s = '1') 
	   report "error when A=1 B=1 and Cin=1" severity warning;
	wait for 5 ns;	
	
	A <= '0';
	B <= '0';
	Cin <= '0';
	
    wait;
	end process;
	
	
end;
 