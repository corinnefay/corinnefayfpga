library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity tb_top_grey_gauss_har is
end tb_top_grey_gauss_har;

architecture Behavioral of tb_top_grey_gauss_har is
     signal clk_in         : std_logic := '0';
 	signal resetn      : std_logic := '1';
	signal reset       : std_logic := '0';
    signal filter_sel : std_logic := '0';
    --signal harris_level : STD_LOGIC_VECTOR(31 downto 0);
    --signal max_harris   : std_logic_vector (31 downto 0);
    --signal max_harris_x  : std_logic_vector (31 downto 0);
    --signal max_harris_y: std_logic_vector (31 downto 0);
    signal axi4s_i_tdata : STD_LOGIC_VECTOR (23 downto 0);
    signal axi4s_i_tvalid : STD_LOGIC;
    signal axi4s_i_tready : STD_LOGIC;
    signal axi4s_i_tlast : STD_LOGIC;
    signal axi4s_i_tuser : STD_LOGIC;
    signal axi4s_o_tdata : STD_LOGIC_VECTOR (23 downto 0);
    signal axi4s_o_tvalid : STD_LOGIC;
    signal axi4s_o_tready : STD_LOGIC;
    signal axi4s_o_tlast : STD_LOGIC;
    signal axi4s_o_tuser : STD_LOGIC;

	-- Les constantes suivantes permette de definir la frequence de l'horloge 
	constant hp : time := 20ns;      --demi periode de 20ns
	constant period : time := 2 * hp;  --periode de 40ns, soit une frequence de 25MHz
  	constant data_width_c : integer := 8;      --taille du bus de donnee pour chaque couleur 
	constant data_width : integer := 24;      --taille du bus de donnee de l'axi4s	
      signal done : std_logic;
    signal img_cnt : integer;
    signal line_cnt : integer;
    signal pixel_cnt : integer;
    component top_grey_gauss_har is
        port (
            clk_in        : in  STD_LOGIC;
            resetn      : in  STD_LOGIC;
            filter_sel          : in  STD_LOGIC;
            --harris_level : in STD_LOGIC_VECTOR(31 downto 0);
            --max_harris   : out std_logic_vector (31 downto 0);
            --max_harris_x  : out std_logic_vector (31 downto 0);
            --max_harris_y: out std_logic_vector (31 downto 0);
            -- AXI4-Stream Video input
            axi4s_i_tdata  : in STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_i_tvalid : in STD_LOGIC;
            axi4s_i_tready : out  STD_LOGIC;
            axi4s_i_tlast  : in STD_LOGIC;
            axi4s_i_tuser  : in STD_LOGIC;
            -- AXI4-Stream Video output
            axi4s_o_tdata  : out STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_o_tvalid : out STD_LOGIC;
            axi4s_o_tready : in  STD_LOGIC;
            axi4s_o_tlast  : out STD_LOGIC;
            axi4s_o_tuser  : out STD_LOGIC);
    end component;
    component axi4s_driver is
    generic (
        G_FILE_PATH         : string  := "sample_in_alea.txt";
        G_DATA_WIDTH        : integer := data_width_c;
        G_INIT_DELAY        : integer := 0;
        G_TLAST_END_OF_LINE : boolean := true;
        G_LOOP_COUNT        : integer := 0   -- 0 = boucle infinie
    );
    Port ( 
        clk_i : in STD_LOGIC;
        rst_i : in STD_LOGIC;
        m_tvalid : out STD_LOGIC;
        m_tdata : out STD_LOGIC_VECTOR (data_width_c-1 downto 0);
        m_tlast : out STD_LOGIC; 
        m_tuser : out STD_LOGIC; 
        m_tready : in STD_LOGIC;
        done_o : out STD_LOGIC;
        frame_cnt_o : out integer;
        pixel_cnt_o : out integer);
    end component;
    component axi4s_monitor is
        generic (
            G_FILE_BASENAME : string  := "stream_top_out";
            G_DATA_WIDTH    : integer := 8;
            G_IMG_WIDTH     : integer := 640;
            G_IMG_HEIGHT    : integer := 480;
            G_NB_IMAGES     : integer := 6;
            G_TIMEOUT_CY    : integer := 10000;
            G_SYNC_ON_SOF   : boolean := false
        );
        port (
            clk_i    : in  std_logic;
            rst_i    : in  std_logic;    -- reset actif haut
            s_tvalid : in  std_logic;
            s_tdata  : in  std_logic_vector(G_DATA_WIDTH-1 downto 0);
            s_tlast  : in  std_logic;
            s_tuser  : in  std_logic := '0';   -- SOF : '1' sur le premier pixel de trame
            s_tready : out std_logic;
            done_o      : out std_logic;  -- '1' apres capture de toutes les images
            img_cnt_o   : out integer;    -- indice de l'image en cours
            line_cnt_o  : out integer;    -- lignes capturees dans l'image courante
            pixel_cnt_o : out integer     -- pixels totaux captures
        );
        end component;



begin
	dut: top_grey_gauss_har
        port map (
            clk_in => clk_in,
            resetn => resetn,
            filter_sel => filter_sel,
            axi4s_i_tdata  => axi4s_i_tdata,
            axi4s_i_tvalid => axi4s_i_tvalid,
            axi4s_i_tready => axi4s_i_tready,
            axi4s_i_tlast  => axi4s_i_tlast,
            axi4s_i_tuser  => axi4s_i_tuser,
            axi4s_o_tdata => axi4s_o_tdata,
            axi4s_o_tvalid => axi4s_o_tvalid,
            axi4s_o_tready => axi4s_o_tready,
            axi4s_o_tlast => axi4s_o_tlast,
            axi4s_o_tuser => axi4s_o_tuser
		
        );


            axi4s_driver_r : axi4s_driver
--        generic map(
--            G_FILE_PATH => "sample_in_r.txt",
--            G_DATA_WIDTH =>8
--       )      
        port map (
            clk_i => clk_in,
            rst_i => reset,
            m_tvalid => axi4s_i_tvalid,
            m_tdata => axi4s_i_tdata(23 downto 16),
            m_tlast => axi4s_i_tlast, 
            m_tuser => axi4s_i_tuser, 
            m_tready => axi4s_i_tready,
            done_o => open,
            frame_cnt_o => open,
            pixel_cnt_o => open
            );
    axi4s_driver_g : axi4s_driver
--        generic map(
--            G_FILE_PATH => "sample_in_g.txt",
--            G_DATA_WIDTH =>8
--        )        
        port map (
            clk_i => clk_in,
            rst_i => reset,
            m_tvalid => axi4s_i_tvalid,
            m_tdata => axi4s_i_tdata(15 downto 8),
            m_tuser => axi4s_i_tuser, 
            m_tlast => axi4s_i_tlast, 
            m_tready => axi4s_i_tready,
            done_o => open,
            frame_cnt_o => open,
            pixel_cnt_o => open
            );
    axi4s_driver_b : axi4s_driver
--        generic map(
--            G_FILE_PATH => "sample_in_b.txt",
--            G_DATA_WIDTH =>8
--       )
        port map (
            clk_i => clk_in,
            rst_i => reset,
            m_tvalid => axi4s_i_tvalid,
            m_tdata => axi4s_i_tdata(7 downto 0),
            m_tlast => axi4s_i_tlast, 
            m_tuser => axi4s_i_tuser, 
            m_tready => axi4s_i_tready,
            done_o => open,
            frame_cnt_o => open,
            pixel_cnt_o => open
            );	
    axi4s_monitor_r :  axi4s_monitor
        generic map(
            G_FILE_BASENAME => "stream_topr_out"
        )
        port map(
            clk_i    => clk_in,
            rst_i   => reset,  
            s_tvalid => axi4s_o_tvalid,
            s_tdata  => axi4s_o_tdata(23 downto 16),
            s_tlast  => axi4s_o_tlast,
            s_tuser  => axi4s_o_tuser,   
            s_tready => axi4s_o_tready,
            done_o      =>open,  
            img_cnt_o   =>open,  
            line_cnt_o  =>open,   
            pixel_cnt_o =>open   
        );
    axi4s_monitor_g :  axi4s_monitor
        generic map (
            G_FILE_BASENAME => "stream_topg_out"
        )
        port map(
            clk_i    => clk_in,
            rst_i   => reset,  
            s_tvalid => axi4s_o_tvalid,
            s_tdata  => axi4s_o_tdata(15 downto 8),
            s_tlast  => axi4s_o_tlast,
            s_tuser  => axi4s_o_tuser,   
            s_tready => axi4s_o_tready,
            done_o      =>open,  
            img_cnt_o   =>open,  
            line_cnt_o  =>open,   
            pixel_cnt_o =>open   
        );
    axi4s_monitor_b :  axi4s_monitor
        generic map(
            G_FILE_BASENAME => "stream_topb_out"
        )
        port map(
            clk_i    => clk_in,
            rst_i   => reset,    
            s_tvalid => axi4s_o_tvalid,
            s_tdata  => axi4s_o_tdata(7 downto 0),
            s_tlast  => axi4s_o_tlast,
            s_tuser  => axi4s_o_tuser,   
            s_tready => axi4s_o_tready,
            done_o      =>done,
            img_cnt_o   =>img_cnt,
            line_cnt_o  =>line_cnt,   
            pixel_cnt_o =>pixel_cnt   
        );
	--Simulation du signal d'horloge en continue
	process
    begin
		wait for hp;
		clk_in <= not clk_in;
	end process;
	process
    begin
        reset <= '1';
        resetn <= '0';
        --axi4s_o_tready <= '0';

        wait for 100ns;
       --axi4s_o_tready <= '0';
        reset <= '0';
        resetn <= '1';   
        --harris_level(31 downto 8) <= (others => '0');
        --harris_level(7 downto 0) <=(others => '0');
        --harris_level(7 downto 0) <="01111101";
        filter_sel <= '0';

        wait for 1ms;
        --filter_sel <= '1';

        wait;
	end process;    
end Behavioral;
