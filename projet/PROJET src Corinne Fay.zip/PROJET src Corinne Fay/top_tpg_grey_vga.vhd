library ieee;
use ieee.std_logic_1164.all;

entity top_tpg_grey_vga is
    generic (
        DATA_WIDTH : integer := 24
    );  
    port(
        clk_in         : in std_logic;
        resetn      : in std_logic;
        filter_sel  : in std_logic;
        vga_hsync   : out std_logic;
        vga_vsync   : out std_logic;
        vga_red     : out std_logic_vector (3 downto 0);
        vga_green   : out std_logic_vector (3 downto 0);   
        vga_blue    : out std_logic_vector (3 downto 0)
    );
end entity top_tpg_grey_vga;

architecture rtl of top_tpg_grey_vga is
    signal reset : std_logic;
    signal clk : std_logic;
    signal pll_locked : std_logic;
    signal axi4s_gene_grey_tdata  : std_logic_vector (23 downto 0);
    signal axi4s_gene_grey_tvalid : std_logic; 
    signal axi4s_gene_grey_tready : std_logic;
    signal axi4s_gene_grey_tlast  : std_logic;
    signal axi4s_gene_grey_tuser  : std_logic;
    signal axi4s_filter_vga_tdata  : std_logic_vector (23 downto 0);
    signal axi4s_filter_vga_tvalid : std_logic;
    signal axi4s_filter_vga_tready : std_logic;
    signal axi4s_filter_vga_tlast  : std_logic;
    signal axi4s_filter_vga_tuser  : std_logic;

    
	component filter_grey
        generic (
            DATA_WIDTH : integer := 24;
            COLOR_WIDTH : integer :=8
        );
        port (
            clk          : in  STD_LOGIC;
            resetn       : in  STD_LOGIC;
            -- AXI4-Stream Video input
            axi4s_i_tdata  : in STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_i_tvalid : in STD_LOGIC;
            axi4s_i_tready : out  STD_LOGIC;
            axi4s_i_tlast  : in STD_LOGIC;
            axi4s_i_tuser  : in STD_LOGIC;
            -- AXI4-Stream Video output
            axi4s_o_tdata  : out STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_o_tvalid : out STD_LOGIC;
            axi4s_o_tready : in  STD_LOGIC;
            axi4s_o_tlast  : out STD_LOGIC;
            axi4s_o_tuser  : out STD_LOGIC
        );

	end component;
    component pattern_generator
        generic (
            DATA_WIDTH : integer := 24
        );
        port (
            clk          : in  STD_LOGIC;
            resetn       : in  STD_LOGIC;
            pattern_en   : in STD_LOGIC;
            -- AXI4-Stream Video
            axi4s_tdata  : out STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_tvalid : out STD_LOGIC;
            axi4s_tready : in  STD_LOGIC;
            axi4s_tlast  : out STD_LOGIC;
            axi4s_tuser  : out STD_LOGIC
        );
    end component;
    component axi4s_to_vga
        generic (
            DATA_WIDTH : integer := 24
        );
        port (
            clk          : in  STD_LOGIC;
            resetn       : in  STD_LOGIC;
            -- AXI4-Stream Video input
            axi4s_tdata  : in STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_tvalid : in STD_LOGIC;
            axi4s_tready : out  STD_LOGIC;
            axi4s_tlast  : in STD_LOGIC;
            axi4s_tuser  : in STD_LOGIC;
            -- VGA output
            vga_hsync    : out STD_LOGIC;
            vga_vsync    : out STD_LOGIC;
            vga_red      : out STD_LOGIC_VECTOR(3 downto 0);
            vga_green    : out STD_LOGIC_VECTOR(3 downto 0);   
            vga_blue     : out STD_LOGIC_VECTOR(3 downto 0)
        );
    end component;  
    component clk_wiz_0
        port (
        clk_out1          : out    std_logic;
        reset             : in     std_logic;
        locked            : out    std_logic;
        clk_in1           : in     std_logic
        );
    end component;

    
begin
    reset <= not resetn;
    u_clk_wiz_0 : clk_wiz_0
        port map (
            clk_out1 => clk,
            reset    => reset,
            locked   => pll_locked,
            clk_in1  => clk_in
        );
    u_pattern_generator : pattern_generator
        port map (
            clk          => clk,
            resetn       => resetn,
            pattern_en   => pll_locked,
            axi4s_tdata  => axi4s_gene_grey_tdata,
            axi4s_tvalid => axi4s_gene_grey_tvalid,
            axi4s_tready => axi4s_gene_grey_tready,
            axi4s_tlast  => axi4s_gene_grey_tlast,
            axi4s_tuser  => axi4s_gene_grey_tuser
        );
	u_filter_grey : filter_grey
        port map (
            clk          => clk,
            resetn       => resetn,
            axi4s_i_tdata  => axi4s_gene_grey_tdata,
            axi4s_i_tvalid => axi4s_gene_grey_tvalid,
            axi4s_i_tready => axi4s_gene_grey_tready,
            axi4s_i_tlast  => axi4s_gene_grey_tlast,
            axi4s_i_tuser  => axi4s_gene_grey_tuser,
            axi4s_o_tdata  => axi4s_filter_vga_tdata,
            axi4s_o_tvalid => axi4s_filter_vga_tvalid,
            axi4s_o_tready => axi4s_filter_vga_tready,
            axi4s_o_tlast  => axi4s_filter_vga_tlast,
            axi4s_o_tuser  => axi4s_filter_vga_tuser
        );

    u_axi4s_to_vga : axi4s_to_vga
            port map(
            clk          => clk,    
            resetn       => resetn,
            axi4s_tdata  => axi4s_filter_vga_tdata,
            axi4s_tvalid => axi4s_filter_vga_tvalid,
            axi4s_tready => axi4s_filter_vga_tready,
            axi4s_tlast  => axi4s_filter_vga_tlast,
            axi4s_tuser  => axi4s_filter_vga_tuser,
            vga_hsync    => vga_hsync,  
            vga_vsync    => vga_vsync,
            vga_red      => vga_red,
            vga_green    => vga_green,   
            vga_blue     => vga_blue        
        );



   

    end architecture rtl;
