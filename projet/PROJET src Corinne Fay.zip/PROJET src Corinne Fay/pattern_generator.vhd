library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;


entity pattern_generator is
    generic (
        DATA_WIDTH : integer := 24
    );
    Port (
        clk          : in  STD_LOGIC;
        resetn       : in  STD_LOGIC;
        pattern_en   : in STD_LOGIC;
        -- AXI4-Stream Video
        axi4s_tdata  : out STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
        axi4s_tvalid : out STD_LOGIC;
        axi4s_tready : in  STD_LOGIC;
        axi4s_tlast  : out STD_LOGIC;
        axi4s_tuser  : out STD_LOGIC
    );
end pattern_generator;

architecture Behavioral of pattern_generator is

   
    --***640x480@60Hz***--  Requires 25 MHz clock
    constant FRAME_WIDTH  : natural := 640;
    constant FRAME_HEIGHT : natural := 480;

    --Moving Box constants    
    constant BOX_WIDTH   : natural := 8;
    constant BOX_CLK_DIV : natural := 1000000;
    constant BOX_X_MAX : natural := 512 - BOX_WIDTH;
    constant BOX_Y_MAX : natural := FRAME_HEIGHT - BOX_WIDTH;
    constant BOX_X_MIN : natural := 0;
    constant BOX_Y_MIN : natural := 256;
    constant BOX_X_INIT : unsigned(11 downto 0) :=to_unsigned(0, 12);
    constant BOX_Y_INIT : unsigned(11 downto 0) :=to_unsigned(400, 12);
    -- Compteurs image
    signal h_cntr_reg : unsigned(11 downto 0) :=(others => '0');
    signal v_cntr_reg : unsigned(11 downto 0) :=(others => '0');
    -- Couleurs RGB888
    signal red   : std_logic_vector(7 downto 0);
    signal green : std_logic_vector(7 downto 0);
    signal blue  : std_logic_vector(7 downto 0);
    -- Moving box
    signal box_x_reg : unsigned(11 downto 0) := BOX_X_INIT;
    signal box_y_reg : unsigned(11 downto 0) := BOX_Y_INIT;
    signal box_x_dir : std_logic := '1';
    signal box_y_dir : std_logic := '1';
    signal box_cntr_reg : unsigned(24 downto 0) := (others => '0');
    signal pixel_in_box : std_logic;
    signal border_pixel : std_logic;

begin
    -- Generation de la mire red sur 8 bits, vert sur 8 bits et bleu sur 8 bits
    -- mire simplifiee pour simulation avec des donn�es non nulle et non consecutives 
    -- et qui change de valeur sur le bit 4 a chaque coup d'hologe pour la validation du bloc 
--        blue  <= not std_logic_vector(h_cntr_reg(3 downto 0))&  std_logic_vector(h_cntr_reg(3 downto 0));
--        green <= not std_logic_vector(h_cntr_reg(3 downto 0))&  not std_logic_vector(h_cntr_reg(3 downto 0));
--        red   <= not std_logic_vector(h_cntr_reg(3 downto 0)) & '1' & std_logic_vector(h_cntr_reg(2 downto 0)); 
--    -- ajout d'une bordure 
    --border_pixel <= '1' when h_cntr_reg =0 or v_cntr_reg= 0 or h_cntr_reg=FRAME_WIDTH -1  or v_cntr_reg= FRAME_HEIGHT - 1 else '0';
--    --border_pixel <= '1' when h_cntr_reg <2 or v_cntr_reg <2 or h_cntr_reg >FRAME_WIDTH -2  or v_cntr_reg >FRAME_HEIGHT - 2 else '0';
    
    red <=  --(others => '1')                         when border_pixel = '1' else
             std_logic_vector(h_cntr_reg(5 downto 2)) & std_logic_vector(h_cntr_reg(5 downto 2))
                                                    when (h_cntr_reg < 512) and (v_cntr_reg < 256) and (h_cntr_reg(8) = '1') else
            (others => '1')                         when(h_cntr_reg < 512) and (v_cntr_reg >= 256) and (pixel_in_box = '0') else
            (others => '1')                         when(h_cntr_reg >= 512) and( (v_cntr_reg(8) = '1' and h_cntr_reg(3) = '1')or(v_cntr_reg(8) = '0' and v_cntr_reg(3) = '1'))else
            (others => '0');
    green <= -- (others => '1')                         when border_pixel = '1' else
             std_logic_vector(h_cntr_reg(5 downto 2)) & std_logic_vector(h_cntr_reg(5 downto 2))
                                                    when(h_cntr_reg < 512) and (v_cntr_reg < 256) and(h_cntr_reg(7) = '1') else
            (others => '1')                         when(h_cntr_reg < 512) and(v_cntr_reg >= 256) and(pixel_in_box = '0')else
            (others => '1')                         when(h_cntr_reg >= 512) and((v_cntr_reg(8) = '1' and h_cntr_reg(3) = '1')or(v_cntr_reg(8) = '0' and v_cntr_reg(3) = '1'))else
            (others => '0');
    blue <= -- (others => '1')                         when border_pixel = '1' else
             std_logic_vector(h_cntr_reg(5 downto 2)) & std_logic_vector(h_cntr_reg(5 downto 2))
                                                    when(h_cntr_reg < 512) and(v_cntr_reg < 256) and(h_cntr_reg(6) = '1')else
            (others => '1')                         when(h_cntr_reg < 512) and(v_cntr_reg >= 256) and(pixel_in_box = '0')else
            (others => '1')                         when(h_cntr_reg >= 512) and((v_cntr_reg(8) = '1' and h_cntr_reg(3) = '1')or(v_cntr_reg(8) = '0' and v_cntr_reg(3) = '1'))else
            (others => '0');

    -- moving box 
    box:process (clk)
    begin
        if resetn = '0' then
            box_cntr_reg <= (others => '0');
            box_x_reg <= BOX_X_INIT;
            box_y_reg <= BOX_Y_INIT;
            box_x_dir <= '1';
            box_y_dir <= '1';
        elsif (rising_edge(clk)) then
            if ((box_x_dir = '1' and (box_x_reg = BOX_X_MAX - 1)) or (box_x_dir = '0' and (box_x_reg = BOX_X_MIN + 1))) then
                box_x_dir <= not(box_x_dir);
            end if;
            if ((box_y_dir = '1' and (box_y_reg = BOX_Y_MAX - 1)) or (box_y_dir = '0' and (box_y_reg = BOX_Y_MIN + 1))) then
                box_y_dir <= not(box_y_dir);
            end if;
            if (box_cntr_reg = (BOX_CLK_DIV - 1)) then
                box_cntr_reg <= (others=>'0');
                if (box_x_dir = '1') then
                    box_x_reg <= box_x_reg + 1;
                else
                    box_x_reg <= box_x_reg - 1;
                end if;
                if (box_y_dir = '1') then
                    box_y_reg <= box_y_reg + 1;
                else
                    box_y_reg <= box_y_reg - 1;
                end if;
             else
                box_cntr_reg <= box_cntr_reg + 1;     
            end if;
        end if;
    end process;
    pixel_in_box <= '1' when (((h_cntr_reg >= box_x_reg) and (h_cntr_reg < (box_x_reg + BOX_WIDTH))) and
                              ((v_cntr_reg >= box_y_reg) and (v_cntr_reg < (box_y_reg + BOX_WIDTH)))) else
                    '0';
    
    -- compteur horizontal et vertical              
    counter:process(clk, resetn)
    begin
        if resetn = '0' then
            h_cntr_reg <= (others => '0');
            v_cntr_reg <= (others => '0');
        elsif rising_edge(clk) then
            if pattern_en = '0' then 
                h_cntr_reg <= (others => '0');
                v_cntr_reg <= (others => '0');
            elsif axi4s_tready = '1' then 
                if h_cntr_reg = (FRAME_WIDTH - 1) then
                    h_cntr_reg <= (others => '0');
                    if v_cntr_reg = (FRAME_HEIGHT - 1)  then
                        v_cntr_reg <= (others => '0');
                    else
                        v_cntr_reg <= v_cntr_reg + 1;
                    end if;
                else
                    h_cntr_reg <= h_cntr_reg + 1;
                end if;
             end if;
        end if;
    end process;
    -- sortie en AXI4-Stream
    axi4s_tuser <= '1' when pattern_en= '1' and h_cntr_reg = 0 and v_cntr_reg = 0 else '0';
    axi4s_tlast <= '1' when pattern_en= '1' and h_cntr_reg = (FRAME_WIDTH - 1) else '0';
    axi4s_tdata  <= red & green & blue ;
    axi4s_tvalid <= pattern_en;


end Behavioral;