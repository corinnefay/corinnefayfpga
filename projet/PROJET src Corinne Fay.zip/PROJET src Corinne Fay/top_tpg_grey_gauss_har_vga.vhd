library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity top_tpg_grey_gauss_har_vga is
    generic (
        DATA_WIDTH : integer := 24
    );  
    port(
        clk_in        : in std_logic;
        resetn      : in std_logic;
        filter_sel  : in std_logic;
        --harris_level : in STD_LOGIC_VECTOR(31 downto 0);
        --max_harris   : out std_logic_vector (31 downto 0);
        --max_harris_x  : out std_logic_vector (31 downto 0);
        --max_harris_y: out std_logic_vector (31 downto 0);

        vga_hsync   : out std_logic;
        vga_vsync   : out std_logic;
        vga_red     : out std_logic_vector (3 downto 0);
        vga_green   : out std_logic_vector (3 downto 0);   
        vga_blue    : out std_logic_vector (3 downto 0)
    );
end entity top_tpg_grey_gauss_har_vga;

architecture rtl of top_tpg_grey_gauss_har_vga is
    signal reset : std_logic;
    signal clk : std_logic;
    signal pll_locked : std_logic;
    signal gene_grey_tdata  : std_logic_vector (23 downto 0);
    signal gene_grey_tvalid : std_logic; 
    signal gene_grey_tready : std_logic;
    signal gene_grey_tlast  : std_logic;
    signal gene_grey_tuser  : std_logic;
    signal grey_gauss_tdata  : std_logic_vector (23 downto 0);
    signal grey_gauss_tvalid : std_logic; 
    signal grey_gauss_tready : std_logic;
    signal grey_gauss_tlast  : std_logic;
    signal grey_gauss_tuser  : std_logic;
    signal gauss_harris_tdata  : std_logic_vector (23 downto 0);
    signal gauss_harris_tvalid : std_logic; 
    signal gauss_harris_tready : std_logic;
    signal gauss_harris_tlast  : std_logic;
    signal gauss_harris_tuser  : std_logic;
    signal harris_level : STD_LOGIC_VECTOR( 9 downto 0) := std_logic_vector(to_unsigned(20, 10));
    signal filter_vga_tdata  : std_logic_vector (23 downto 0);
    signal filter_vga_tvalid : std_logic;
    signal filter_vga_tready : std_logic;
    signal filter_vga_tlast  : std_logic;
    signal filter_vga_tuser  : std_logic;

    component filter_harris  is
        generic (
            DATA_WIDTH : integer := 24;
            COLOR_WIDTH : integer :=8
        );
        Port (
            clk          : in  STD_LOGIC;
            resetn       : in  STD_LOGIC;
            harris_level : in STD_LOGIC_VECTOR(9 downto 0);
            max_harris   : out std_logic_vector (10 downto 0);
            max_harris_x  : out std_logic_vector (9 downto 0);
            max_harris_y: out std_logic_vector (9 downto 0);
            -- AXI4-Stream Video input
            axi4s_i_tdata  : in STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_i_tvalid : in STD_LOGIC;
            axi4s_i_tready : out  STD_LOGIC;
            axi4s_i_tlast  : in STD_LOGIC;
            axi4s_i_tuser  : in STD_LOGIC;
            -- AXI4-Stream Video output
            axi4s_o_tdata  : out STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_o_tvalid : out STD_LOGIC;
            axi4s_o_tready : in  STD_LOGIC;
            axi4s_o_tlast  : out STD_LOGIC;
            axi4s_o_tuser  : out STD_LOGIC
            );
    end component;
    component filter_gauss  is
        generic (
            DATA_WIDTH : integer := 24;
            COLOR_WIDTH : integer :=8
        );
        Port (
            clk          : in  STD_LOGIC;
            resetn       : in  STD_LOGIC;
            -- AXI4-Stream Video input
            axi4s_i_tdata  : in STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_i_tvalid : in STD_LOGIC;
            axi4s_i_tready : out  STD_LOGIC;
            axi4s_i_tlast  : in STD_LOGIC;
            axi4s_i_tuser  : in STD_LOGIC;
            -- AXI4-Stream Video output
            axi4s_o_tdata  : out STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_o_tvalid : out STD_LOGIC;
            axi4s_o_tready : in  STD_LOGIC;
            axi4s_o_tlast  : out STD_LOGIC;
            axi4s_o_tuser  : out STD_LOGIC
            );
    end component;    
	component filter_grey
        generic (
            DATA_WIDTH : integer := 24;
            COLOR_WIDTH : integer :=8
        );
        port (
            clk          : in  STD_LOGIC;
            resetn       : in  STD_LOGIC;
            -- AXI4-Stream Video input
            axi4s_i_tdata  : in STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_i_tvalid : in STD_LOGIC;
            axi4s_i_tready : out  STD_LOGIC;
            axi4s_i_tlast  : in STD_LOGIC;
            axi4s_i_tuser  : in STD_LOGIC;
            -- AXI4-Stream Video output
            axi4s_o_tdata  : out STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_o_tvalid : out STD_LOGIC;
            axi4s_o_tready : in  STD_LOGIC;
            axi4s_o_tlast  : out STD_LOGIC;
            axi4s_o_tuser  : out STD_LOGIC
        );

	end component;
    component pattern_generator
        generic (
            DATA_WIDTH : integer := 24
        );
        port (
            clk          : in  STD_LOGIC;
            resetn       : in  STD_LOGIC;
            pattern_en   : in STD_LOGIC;
            -- AXI4-Stream Video
            axi4s_tdata  : out STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_tvalid : out STD_LOGIC;
            axi4s_tready : in  STD_LOGIC;
            axi4s_tlast  : out STD_LOGIC;
            axi4s_tuser  : out STD_LOGIC
        );
    end component;
    component axi4s_to_vga
        generic (
            DATA_WIDTH : integer := 24
        );
        port (
            clk          : in  STD_LOGIC;
            resetn       : in  STD_LOGIC;
            -- AXI4-Stream Video input
            axi4s_tdata  : in STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_tvalid : in STD_LOGIC;
            axi4s_tready : out  STD_LOGIC;
            axi4s_tlast  : in STD_LOGIC;
            axi4s_tuser  : in STD_LOGIC;
            -- VGA output
            vga_hsync    : out STD_LOGIC;
            vga_vsync    : out STD_LOGIC;
            vga_red      : out STD_LOGIC_VECTOR(3 downto 0);
            vga_green    : out STD_LOGIC_VECTOR(3 downto 0);   
            vga_blue     : out STD_LOGIC_VECTOR(3 downto 0)
        );
    end component;  
    component clk_wiz_0
        port (
        clk_out1          : out    std_logic;
        reset             : in     std_logic;
        locked            : out    std_logic;
        clk_in1           : in     std_logic
        );
    end component;

    
begin
    reset <= not resetn;
    u_clk_wiz_0 : clk_wiz_0
        port map (
            clk_out1 => clk,
            reset    => reset,
            locked   => pll_locked,
            clk_in1  => clk_in
        );
    u_pattern_generator : pattern_generator
        port map (
            clk          => clk,
            resetn       => resetn,
            pattern_en   => pll_locked,
            axi4s_tdata  => gene_grey_tdata,
            axi4s_tvalid => gene_grey_tvalid,
            axi4s_tready => gene_grey_tready,
            axi4s_tlast  => gene_grey_tlast,
            axi4s_tuser  => gene_grey_tuser
        );
	u_filter_grey : filter_grey
        port map (
            clk          => clk,
            resetn       => resetn,
            axi4s_i_tdata  => gene_grey_tdata,
            axi4s_i_tvalid => gene_grey_tvalid,
            axi4s_i_tready => gene_grey_tready,
            axi4s_i_tlast  => gene_grey_tlast,
            axi4s_i_tuser  => gene_grey_tuser,
            axi4s_o_tdata  => grey_gauss_tdata,
            axi4s_o_tvalid => grey_gauss_tvalid,
            axi4s_o_tready => grey_gauss_tready,
            axi4s_o_tlast  => grey_gauss_tlast,
            axi4s_o_tuser  => grey_gauss_tuser
        );
	u_filter_gauss : filter_gauss
        port map (
            clk          => clk,
            resetn       => resetn,
            axi4s_i_tdata  => grey_gauss_tdata,
            axi4s_i_tvalid => grey_gauss_tvalid,
            axi4s_i_tready => grey_gauss_tready,
            axi4s_i_tlast  => grey_gauss_tlast,
            axi4s_i_tuser  => grey_gauss_tuser,
            axi4s_o_tdata  => gauss_harris_tdata,
            axi4s_o_tvalid => gauss_harris_tvalid,
            axi4s_o_tready => gauss_harris_tready,
            axi4s_o_tlast  => gauss_harris_tlast,
            axi4s_o_tuser  => gauss_harris_tuser

       );
	u_filter_harris : filter_harris
        port map (
            clk          => clk,
            resetn       => resetn,
            harris_level =>harris_level,
            max_harris   =>open,
            max_harris_x  =>open,
            max_harris_y=>open,
            axi4s_i_tdata  => gauss_harris_tdata,
            axi4s_i_tvalid => gauss_harris_tvalid,
            axi4s_i_tready => gauss_harris_tready,
            axi4s_i_tlast  => gauss_harris_tlast,
            axi4s_i_tuser  => gauss_harris_tuser,
            axi4s_o_tdata  => filter_vga_tdata,
            axi4s_o_tvalid => filter_vga_tvalid,
            axi4s_o_tready => filter_vga_tready,
            axi4s_o_tlast  => filter_vga_tlast,
            axi4s_o_tuser  => filter_vga_tuser

       );
    u_axi4s_to_vga : axi4s_to_vga
            port map(
            clk          => clk,    
            resetn       => resetn,
            axi4s_tdata  => filter_vga_tdata,
            axi4s_tvalid => filter_vga_tvalid,
            axi4s_tready => filter_vga_tready,
            axi4s_tlast  => filter_vga_tlast,
            axi4s_tuser  => filter_vga_tuser,
            vga_hsync    => vga_hsync,  
            vga_vsync    => vga_vsync,
            vga_red      => vga_red,
            vga_green    => vga_green,   
            vga_blue     => vga_blue        
        );



   

    end architecture rtl;
