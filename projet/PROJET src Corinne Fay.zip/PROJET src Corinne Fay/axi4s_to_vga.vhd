library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity axi4s_to_vga is
      generic (
        DATA_WIDTH        : integer := 24
      );
      Port ( clk : in STD_LOGIC;
           resetn : in STD_LOGIC;
           axi4s_tdata : in STD_LOGIC_VECTOR (DATA_WIDTH-1 downto 0);
           axi4s_tvalid : in STD_LOGIC;
           axi4s_tready : out STD_LOGIC;
           axi4s_tlast : in STD_LOGIC;
           axi4s_tuser : in STD_LOGIC;
           vga_hsync : out STD_LOGIC;
           vga_vsync : out STD_LOGIC;
           vga_red : out STD_LOGIC_VECTOR (3 downto 0);
           vga_green : out STD_LOGIC_VECTOR (3 downto 0);   
           vga_blue : out STD_LOGIC_VECTOR (3 downto 0));
end axi4s_to_vga;

architecture Behavioral of axi4s_to_vga is
    --***640x480@60Hz***--  Requires 25 MHz clock
    constant FRAME_WIDTH : natural := 640;
    constant FRAME_HEIGHT : natural := 480;

    constant H_FP : natural := 16; --H front porch width (pixels)
    constant H_PW : natural := 96; --H sync pulse width (pixels)
    constant H_MAX : natural := 800; --H total period (pixels)

    constant V_FP : natural := 10; --V front porch width (lines)
    constant V_PW : natural := 2; --V sync pulse width (lines)
    constant V_MAX : natural := 525; --V total period (lines)

    constant H_POL : std_logic := '0';
    constant V_POL : std_logic := '0';
    -- les compteurs de lignes et colonnes
    signal h_count : natural range 0 to H_MAX - 1 := 0; 
    signal v_count : natural range 0 to V_MAX - 1 := 0;
    -- signaux axistream
    signal handshake : std_logic :='0';
    signal axi4s_tready_b : std_logic :='0';
    signal wait_frame : std_logic :='0';
    
    begin

    -- generation des signaux de synchronisation VGA
    vga_hsync <= '0' when (h_count >= FRAME_WIDTH + H_FP and h_count < FRAME_WIDTH + H_FP + H_PW) else '1';
    vga_vsync <= '0' when (v_count >= FRAME_HEIGHT + V_FP and v_count < FRAME_HEIGHT + V_FP + V_PW) else '1';
    vga_red <= axi4s_tdata(23 downto 20) when handshake = '1' else (others => '0');
    vga_green <= axi4s_tdata(15 downto 12)when handshake = '1' else (others => '0');
    vga_blue <= axi4s_tdata(7 downto 4) when handshake = '1' else (others => '0');
            
    -- signaux axi stream
    axi4s_tready_b <= '1'when h_count < FRAME_WIDTH and v_count < FRAME_HEIGHT else '0';
    axi4s_tready <= axi4s_tready_b;
    handshake <= axi4s_tready_b and axi4s_tvalid ; 
    
    process(clk,resetn)
    begin
        if resetn = '0' then
            h_count <= 0;
            v_count <= 0;
            wait_frame <= '1';
        elsif rising_edge(clk) then
            -- attente de la premi�re frame apr�s reset
            if wait_frame = '1' then 
                if axi4s_tuser = '1' and  handshake = '1' then 
                    -- les compteur h_count doit �tre mis � 1 au coup d'horloge suivant tuser
                    h_count <= 1;
                    v_count <= 0;
                    wait_frame <= '0';
                 end if;
            else
                if axi4s_tuser = '1' and  handshake = '1' then 
                    h_count <= 1;
                    v_count <= 0;
                elsif h_count = H_MAX -1 then
                        h_count <= 0;
                        if v_count = V_MAX -1 then
                            v_count <= 0;
                        else
                            v_count <= v_count + 1;
                        end if;
                    else
                        h_count <= h_count + 1;
                    end if;
                end if;
            end if;
    end process;
end Behavioral;
