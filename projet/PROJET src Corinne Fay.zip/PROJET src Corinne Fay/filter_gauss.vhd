library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;


entity filter_gauss  is
    generic (
        DATA_WIDTH : integer := 24;
        COLOR_WIDTH : integer :=8
    );
    Port (
        clk          : in  STD_LOGIC;
        resetn       : in  STD_LOGIC;
        -- AXI4-Stream Video input
        axi4s_i_tdata  : in STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
        axi4s_i_tvalid : in STD_LOGIC;
        axi4s_i_tready : out  STD_LOGIC;
        axi4s_i_tlast  : in STD_LOGIC;
        axi4s_i_tuser  : in STD_LOGIC;
        -- AXI4-Stream Video output
        axi4s_o_tdata  : out STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
        axi4s_o_tvalid : out STD_LOGIC;
        axi4s_o_tready : in  STD_LOGIC;
        axi4s_o_tlast  : out STD_LOGIC;
        axi4s_o_tuser  : out STD_LOGIC
        );
end filter_gauss;

architecture Behavioral of filter_gauss is
     -- register pour l'axistream independant
    signal reg1_tdata : std_logic_vector(DATA_WIDTH-1 downto 0);
    signal reg1_tuser : std_logic := '0';
    signal reg1_tlast: std_logic := '0';
    signal reg1_empty: std_logic := '1';
    signal reg1_dispo: std_logic := '1';
    signal reg2_tdata : std_logic_vector(DATA_WIDTH-1 downto 0);
    signal reg2_tuser : std_logic := '0';
    signal reg2_tlast: std_logic := '0';
    signal reg2_empty: std_logic := '1';
    signal reg2_dispo: std_logic := '1';

    signal handshake_in : std_logic :='0';
    signal handshake_out : std_logic :='0';
    signal handshakes : std_logic_vector(1 downto 0);
    signal axi4s_i_tready_b : std_logic :='0';
    signal axi4s_o_tvalid_b : std_logic :='0';

    -- filtrage
    constant FRAME_WIDTH : natural := 640;
    constant FRAME_HEIGHT : natural := 480;
    signal h_count : natural range 0 to FRAME_WIDTH - 1 := 0; 
    signal v_count : natural range 0 to FRAME_HEIGHT - 1 := 0;
    type line_type is array (0 to FRAME_WIDTH-1) of unsigned(7 downto 0);
    signal line1 : line_type;
    signal line2 : line_type;
    signal line1_full : std_logic :='0';
    signal line2_full : std_logic :='0';
    signal matrix_full : std_logic :='0';
    signal first_line : std_logic :='0';
    signal first_pix : std_logic :='0';
    signal last_line : std_logic :='0';
    signal first_line_pix_last : std_logic :='0';
    
    signal last_line_detect : std_logic :='0';
    signal last_pix : std_logic :='0';
    signal last_pix_last_line : std_logic :='0';
    signal p00,p01,p02   : unsigned(COLOR_WIDTH-1 downto 0) := (others => '0');   
    signal p10,p11,p12   : unsigned(COLOR_WIDTH-1 downto 0) := (others => '0');    
    signal p20,p21,p22   : unsigned(COLOR_WIDTH-1 downto 0) := (others => '0');    
    signal sum_gauss  : unsigned(COLOR_WIDTH+3 downto 0);
    signal gauss  : unsigned(COLOR_WIDTH-1 downto 0);
    signal gauss_tdata : std_logic_vector(COLOR_WIDTH-1 downto 0);
    signal gauss_tlast : std_logic;
    signal gauss_tuser : std_logic;
    signal gauss_ready : std_logic;
    signal start_frame : std_logic;
    signal stop_counter : std_logic;
    
    signal pixl0,pixc0,pixlast,pixclast   : unsigned(COLOR_WIDTH-1 downto 0) := (others => '0');    

 begin
    -- compteur de lignes et colonnes
    in_hvcount: process(clk, resetn)
    begin
        if resetn = '0' then
            h_count <= 0;
            v_count <= 0;
         elsif rising_edge (clk) then 
            -- on compte pour la derniere ligne de la frame 
            if last_line_detect = '1' and stop_counter = '0' then 
                if reg1_dispo = '1' then
                  if h_count = FRAME_WIDTH -1 then
                        h_count <= 0;
                   else
                        h_count <= h_count + 1;
                    end if;
                end if; 
            end if;        
            -- on compte si handshake est ok 
            if handshake_in = '1' then 
                if axi4s_i_tuser = '1' then 
                    h_count <= 1;
                    v_count <= 0;
                elsif h_count = FRAME_WIDTH -1 then
                    h_count <= 0;
                    if v_count = FRAME_HEIGHT -1 then
                        v_count <= 0;
                    else
                        v_count <= v_count + 1;
                    end if;
                elsif stop_counter  = '0' then 
                    h_count <= h_count + 1;
                end if;
            end if;
        end if ;    
    end process;

   fill_line: process(clk, resetn)
    begin
        if resetn = '0' then
            line1_full <= '0';
            line2_full <= '0';
        elsif rising_edge(clk) then
            if handshake_in = '1' then
                if axi4s_i_tuser = '1' then
                    line1_full <= '0';
                    line2_full <= '0';
                    --line1(0) <= unsigned(axi4s_i_tdata(7 downto 0));
                -- ajout pour essai implemetnation en ram 
                end if;
                --else
                    line2(h_count) <= line1(h_count);
                    line1(h_count) <= unsigned(axi4s_i_tdata(7 downto 0));
                    if h_count = FRAME_WIDTH - 1 and v_count = 0 then
                        line1_full <= '1';
                    end if;
                    if h_count = FRAME_WIDTH - 1 and v_count = 1 then
                        line2_full <= '1';
                    end if;
                --end if;
            end if;
        end if;
    end process;

    -- matrice pour le calcul de la grille de filtrage
    fill_matrix: process(clk, resetn)
    begin
        if resetn = '0' then
            matrix_full <= '0';
            p00 <= (others => '0'); p01 <= (others => '0'); p02 <= (others => '0');
            p10 <= (others => '0'); p11 <= (others => '0'); p12 <= (others => '0');
            p20 <= (others => '0'); p21 <= (others => '0'); p22 <= (others => '0');
        elsif rising_edge(clk) then
            -- on ne fait avancer la calcul que s il y a de la place pour le stocker dans les registres 
            if reg1_dispo = '1' then
                matrix_full <= '0';
                -- on lit la donn�uniquemetn sur le handshake d'entree
                if handshake_in = '1' then
                    if axi4s_i_tuser = '1' then
                        p00 <= (others => '0'); p01 <= (others => '0'); p02 <= (others => '0');
                        p10 <= (others => '0'); p11 <= (others => '0'); p12 <= (others => '0');
                        p20 <= (others => '0'); p21 <= (others => '0'); p22 <= (others => '0');
                    elsif line1_full = '1' and line2_full = '1' then
                        -- remplissage de la matrice quand les 2 lines buffers sont pleins
                        p20 <= p21;
                        p21 <= p22;
                        p22 <= unsigned(axi4s_i_tdata(7 downto 0));
                        p10 <= p11;
                        p11 <= p12;
                        p12 <= line1(h_count);
                        p00 <= p01;
                        p01 <= p02;
                        p02 <= line2(h_count);
                        -- la matrice est pleine quand on arrive sur le 3ieme pixel de la 3 ieme colonne
                        if h_count >= 2 and v_count >= 2 then
                            matrix_full <= '1';
                        end if;
                    end if;
                end if;
            end if;
        end if;
    end process;

    borders: process(clk, resetn)
    begin
        if resetn = '0' then
            start_frame <= '0';
            stop_counter <= '0';
            first_line <= '0';
            first_line_pix_last <= '0';
            first_pix <= '0';
            last_line <= '0';
            last_line_detect <= '0';
            last_pix <= '0';
            last_pix_last_line <= '0';
            pixl0 <= (others => '0');
            pixc0 <= (others => '0');
            pixclast <= (others => '0');
            pixlast <= (others => '0');
        elsif rising_edge(clk) then
            if reg1_dispo = '1' then
               
                first_line <= '0';
                first_line_pix_last <= '0';
                first_pix <= '0';
                last_pix <= '0';
                last_line <= '0';
                last_pix_last_line <= '0';
                start_frame <= '0';

                if handshake_in = '1' then
                    if axi4s_i_tuser = '1' then
                        stop_counter <= '0';
                        last_line_detect <= '0';
                    else
                        -- premiere ligne
                        if line1_full = '1' and v_count = 1 then
                            pixl0 <= line1(h_count);
                            first_line <= '1';
                            if h_count = 0 then
                                start_frame <= '1';
                            end if;
                            if h_count = FRAME_WIDTH - 1 then
                                first_line_pix_last <= '1';
                            end if;
                        end if;
                        -- lignes suivantes, on detecte, les premier et dernier pixels
                        if line1_full = '1' and line2_full = '1' then
                            -- on lit la valeur du premier pixel
                            if h_count = 0 and v_count >= 2 then
                                pixc0 <= line1(h_count);
                                first_pix <= '0';
                            end if;
                            -- on attend le cycle suivant pour l'envoyer pour 
                            --ne pas avoir un trou entre le premier pixel et la maxtrix_full
                            if h_count = 1 and v_count >= 2 then
                                first_pix <= '1';
                            end if;
                            if h_count = FRAME_WIDTH - 1 then
                                pixclast <= line1(h_count);
                                stop_counter <= '1';
                                if v_count = FRAME_HEIGHT - 1 then
                                    -- aVRRIFE RCE N4EST PAS UN COUP TRIOP TARD
                                    last_line_detect <= '1';
                                end if;
                            end if;
                        end if;
                    end if;
                elsif stop_counter = '1' then
                    -- on ecrit le denier pixel de la ligne enregitre dans pixlast et on redemarre le compteur 
                    last_pix <= '1';
                    stop_counter <= '0';
                elsif last_line_detect = '1' then
                    --derniere ligne 
                    -- les valeurs des pixels de la ligne en cours de transmissionsont dans line1
                    pixlast <= line1(h_count);
                    last_line <= '1';
                    if h_count = FRAME_WIDTH - 1 then
                        -- on etteint quand on arrive au dernier pixel de la ligne
                        last_line_detect <= '0';
                        -- verifer si pixclast a pris la bonne valeur et si on l'ectri bien 
                        last_pix_last_line <= '1';
                        pixclast <= line1(h_count);
                        --!!!!stop_counter <= '1';
                    end if;
                end if;
            end if;
        end if;
    end process;
   
    -- calcul du filtrage 
    -- somme avec les coefff
    sum_gauss <=    resize(p00, 12)
                    + shift_left(resize(p01, 12), 1)
                    + resize(p02, 12)
                    + shift_left(resize(p10, 12), 1)
                    + shift_left(resize(p11, 12), 2)
                    + shift_left(resize(p12, 12), 1)
                    + resize(p20, 12)
                    + shift_left(resize(p21, 12), 1)
                    + resize(p22, 12);
    -- division par 16 on decale 4 bits
    gauss <= sum_gauss(11 downto 4);                
    gauss_tdata <= std_logic_vector(pixl0) when first_line = '1'
                else std_logic_vector(pixc0) when first_pix = '1' 
                else std_logic_vector(pixclast) when last_pix = '1' or  last_pix_last_line = '1'
                else std_logic_vector(pixlast) when last_line= '1' 
                else std_logic_vector(gauss) ;
    gauss_tuser <=  start_frame;
    gauss_tlast <= first_line_pix_last or last_pix or last_pix_last_line;
    gauss_ready <=  matrix_full or first_line or first_pix or last_pix  or last_line or last_pix_last_line;
    
    -- signaux axi stream
    axi4s_i_tready_b <= reg1_dispo and not stop_counter and not last_line_detect;
    axi4s_i_tready <=  axi4s_i_tready_b;
    -- les datas sont pretes des que la matrice de calcul est full. 
    -- le calcul se fait sur un cycle 
    axi4s_o_tvalid_b <= not reg2_empty;
    axi4s_o_tvalid <= axi4s_o_tvalid_b;
    reg2_dispo <= reg2_empty or axi4s_o_tready;
    reg1_dispo <= reg1_empty or reg2_dispo;
    
    handshake_in <= axi4s_i_tvalid and axi4s_i_tready_b; 
    handshake_out <= axi4s_o_tvalid_b and axi4s_o_tready;
    handshakes <= gauss_ready & handshake_out;
    
    axi4s_o_tdata <= reg2_tdata; 
    axi4s_o_tlast <= reg2_tlast;
    axi4s_o_tuser <= reg2_tuser; 
    
     --dacalage a deux registre du signal axi stream pour l'indepandance de flus d'entr�e et du flux de sortie
    -- on doit pourvoir stocker les data dans un registre pour s'assurer de rien perdre
    -- et assurer la transmission sans trou sur l'etage suivan
    axireg: process(clk, resetn)
    begin 
        if resetn = '0' then 
            reg1_tdata <= (others =>'0');
            reg1_tuser <= '0';
            reg1_tlast<= '0';
            reg1_empty<= '1';
            reg2_tdata <= (others =>'0');
            reg2_tuser <= '0';
            reg2_tlast<= '0';
            reg2_empty<= '1';
        elsif rising_edge(clk) then
            -- registre de sortie R2
            -- le registre est plein et pret a envoyer la data
            if reg2_dispo = '1' then 
                if reg1_empty = '0' then
                    -- on regarde R1 si plein on transmet R1 dans R2
                    reg2_tdata <= reg1_tdata;
                    reg2_tlast <= reg1_tlast;
                    reg2_tuser <= reg1_tuser; 
                    reg2_empty <= '0';
                else
                    -- rien a mettre dans R2
                    reg2_empty <= '1';
                end if;
            end if;
            -- registre R1
            if reg1_dispo = '1' then
                if gauss_ready = '1' then
                    reg1_tdata <= gauss_tdata & gauss_tdata & gauss_tdata;
                    reg1_tlast <= gauss_tlast;
                    reg1_tuser <= gauss_tuser;
                    reg1_empty <= '0';
                 else
                     reg1_empty <= '1';
                 end if;
            end if;
          end if;
    end process;                  
    
end behavioral; 

