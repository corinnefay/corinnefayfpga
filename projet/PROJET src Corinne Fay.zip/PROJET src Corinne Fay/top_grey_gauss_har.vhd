library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity top_grey_gauss_har is
    generic (
        DATA_WIDTH : integer := 24
    );  
    port(
        clk_in        : in std_logic;
        resetn      : in std_logic;
        filter_sel  : in std_logic;
        --harris_level : in STD_LOGIC_VECTOR(31 downto 0);
        --max_harris   : out std_logic_vector (31 downto 0);
        --max_harris_x  : out std_logic_vector (31 downto 0);
        --max_harris_y: out std_logic_vector (31 downto 0);

        -- AXI4-Stream Video input
        axi4s_i_tdata  : in STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
        axi4s_i_tvalid : in STD_LOGIC;
        axi4s_i_tready : out  STD_LOGIC;
        axi4s_i_tlast  : in STD_LOGIC;
        axi4s_i_tuser  : in STD_LOGIC;
        -- AXI4-Stream Video output
        axi4s_o_tdata  : out STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
        axi4s_o_tvalid : out STD_LOGIC;
        axi4s_o_tready : in  STD_LOGIC;
        axi4s_o_tlast  : out STD_LOGIC;
        axi4s_o_tuser  : out STD_LOGIC
    );
end entity top_grey_gauss_har;

architecture rtl of top_grey_gauss_har is
    signal reset : std_logic;
    signal clk : std_logic;
    signal pll_locked : std_logic;
    signal gene_grey_tdata  : std_logic_vector (23 downto 0);
    signal gene_grey_tvalid : std_logic; 
    signal gene_grey_tready : std_logic;
    signal gene_grey_tlast  : std_logic;
    signal gene_grey_tuser  : std_logic;
    signal grey_gauss_tdata  : std_logic_vector (23 downto 0);
    signal grey_gauss_tvalid : std_logic; 
    signal grey_gauss_tready : std_logic;
    signal grey_gauss_tlast  : std_logic;
    signal grey_gauss_tuser  : std_logic;
    signal gauss_harris_tdata  : std_logic_vector (23 downto 0);
    signal gauss_harris_tvalid : std_logic; 
    signal gauss_harris_tready : std_logic;
    signal gauss_harris_tlast  : std_logic;
    signal gauss_harris_tuser  : std_logic;
    signal harris_level : STD_LOGIC_VECTOR(31 downto 0) := std_logic_vector(to_unsigned(80, 32));
    signal filter_vga_tdata  : std_logic_vector (23 downto 0);
    signal filter_vga_tvalid : std_logic;
    signal filter_vga_tready : std_logic;
    signal filter_vga_tlast  : std_logic;
    signal filter_vga_tuser  : std_logic;

    component filter_harris  is
        generic (
            DATA_WIDTH : integer := 24;
            COLOR_WIDTH : integer :=8
        );
        Port (
            clk          : in  STD_LOGIC;
            resetn       : in  STD_LOGIC;
            harris_level : in STD_LOGIC_VECTOR(9 downto 0);
            max_harris   : out std_logic_vector (10 downto 0);
            max_harris_x  : out std_logic_vector (9 downto 0);
            max_harris_y: out std_logic_vector (9 downto 0);
            -- AXI4-Stream Video input
            axi4s_i_tdata  : in STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_i_tvalid : in STD_LOGIC;
            axi4s_i_tready : out  STD_LOGIC;
            axi4s_i_tlast  : in STD_LOGIC;
            axi4s_i_tuser  : in STD_LOGIC;
            -- AXI4-Stream Video output
            axi4s_o_tdata  : out STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_o_tvalid : out STD_LOGIC;
            axi4s_o_tready : in  STD_LOGIC;
            axi4s_o_tlast  : out STD_LOGIC;
            axi4s_o_tuser  : out STD_LOGIC
            );
    end component;
    component filter_gauss  is
        generic (
            DATA_WIDTH : integer := 24;
            COLOR_WIDTH : integer :=8
        );
        Port (
            clk          : in  STD_LOGIC;
            resetn       : in  STD_LOGIC;
            -- AXI4-Stream Video input
            axi4s_i_tdata  : in STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_i_tvalid : in STD_LOGIC;
            axi4s_i_tready : out  STD_LOGIC;
            axi4s_i_tlast  : in STD_LOGIC;
            axi4s_i_tuser  : in STD_LOGIC;
            -- AXI4-Stream Video output
            axi4s_o_tdata  : out STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_o_tvalid : out STD_LOGIC;
            axi4s_o_tready : in  STD_LOGIC;
            axi4s_o_tlast  : out STD_LOGIC;
            axi4s_o_tuser  : out STD_LOGIC
            );
    end component;    
	component filter_grey
        generic (
            DATA_WIDTH : integer := 24;
            COLOR_WIDTH : integer :=8
        );
        port (
            clk          : in  STD_LOGIC;
            resetn       : in  STD_LOGIC;
            -- AXI4-Stream Video input
            axi4s_i_tdata  : in STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_i_tvalid : in STD_LOGIC;
            axi4s_i_tready : out  STD_LOGIC;
            axi4s_i_tlast  : in STD_LOGIC;
            axi4s_i_tuser  : in STD_LOGIC;
            -- AXI4-Stream Video output
            axi4s_o_tdata  : out STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_o_tvalid : out STD_LOGIC;
            axi4s_o_tready : in  STD_LOGIC;
            axi4s_o_tlast  : out STD_LOGIC;
            axi4s_o_tuser  : out STD_LOGIC
        );

	end component;

    component clk_wiz_0
        port (
        clk_out1          : out    std_logic;
        reset             : in     std_logic;
        locked            : out    std_logic;
        clk_in1           : in     std_logic
        );
    end component;

    
begin
    reset <= not resetn;
--    u_clk_wiz_0 : clk_wiz_0
--        port map (
--            clk_out1 => clk,
--            reset    => reset,
--            locked   => pll_locked,
--            clk_in1  => clk_in
--        );
    clk<= clk_in;
	u_filter_grey : filter_grey
        port map (
            clk          => clk,
            resetn       => resetn,
            axi4s_i_tdata  => axi4s_i_tdata,
            axi4s_i_tvalid => axi4s_i_tvalid,
            axi4s_i_tready => axi4s_i_tready,
            axi4s_i_tlast  => axi4s_i_tlast,
            axi4s_i_tuser  => axi4s_i_tuser,
            axi4s_o_tdata  => grey_gauss_tdata,
            axi4s_o_tvalid => grey_gauss_tvalid,
            axi4s_o_tready => grey_gauss_tready,
            axi4s_o_tlast  => grey_gauss_tlast,
            axi4s_o_tuser  => grey_gauss_tuser
        );
	u_filter_gauss : filter_gauss
        port map (
            clk          => clk,
            resetn       => resetn,
            axi4s_i_tdata  => grey_gauss_tdata,
            axi4s_i_tvalid => grey_gauss_tvalid,
            axi4s_i_tready => grey_gauss_tready,
            axi4s_i_tlast  => grey_gauss_tlast,
            axi4s_i_tuser  => grey_gauss_tuser,
             axi4s_o_tdata  => gauss_harris_tdata,
            axi4s_o_tvalid => gauss_harris_tvalid,
            axi4s_o_tready => gauss_harris_tready,
            axi4s_o_tlast  => gauss_harris_tlast,
            axi4s_o_tuser  => gauss_harris_tuser

       );
	u_filter_harris : filter_harris
        port map (
            clk          => clk,
            resetn       => resetn,
            harris_level =>harris_level,
            max_harris   =>open,
            max_harris_x  =>open,
            max_harris_y=>open,
            axi4s_i_tdata  => gauss_harris_tdata,
            axi4s_i_tvalid => gauss_harris_tvalid,
            axi4s_i_tready => gauss_harris_tready,
            axi4s_i_tlast  => gauss_harris_tlast,
            axi4s_i_tuser  => gauss_harris_tuser,
            axi4s_o_tdata  => axi4s_o_tdata,
            axi4s_o_tvalid => axi4s_o_tvalid,
            axi4s_o_tready => axi4s_o_tready,
            axi4s_o_tlast  => axi4s_o_tlast,
            axi4s_o_tuser  => axi4s_o_tuser

       );


   

    end architecture rtl;
