library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_axi4s_to_vga is
end tb_axi4s_to_vga;

architecture behavioral of tb_axi4s_to_vga is

	signal resetn      : std_logic := '1';
	signal reset       : std_logic := '0';
	signal clk         : std_logic := '0';
    signal axi4s_tdata : STD_LOGIC_VECTOR (23 downto 0);
    signal axi4s_tvalid : STD_LOGIC;
    signal axi4s_tready : STD_LOGIC;
    signal axi4s_tlast : STD_LOGIC;
    signal axi4s_tuser : STD_LOGIC;
    signal vga_hsync : STD_LOGIC;
    signal vga_vsync : STD_LOGIC;
    signal vga_red : STD_LOGIC_VECTOR (3 downto 0);
    signal vga_green : STD_LOGIC_VECTOR (3 downto 0);   
    signal vga_blue : STD_LOGIC_VECTOR (3 downto 0);

    -- Les constantes suivantes permette de definir la frequence de l'horloge 
	constant hp : time := 20ns;      --demi periode de 20ns
	constant period : time := 2 * hp;  --periode de 40ns, soit une frequence de 25MHz
	constant data_width_c : integer := 8;      --taille du bus de donnee pour chaque couleur 
	constant data_width : integer := 24;      --taille du bus de donnee de l'axi4s	

	
	component axi4s_to_vga is
	Generic( DATA_WIDTH        : integer := data_width
      );
    Port ( clk : in STD_LOGIC;
           resetn : in STD_LOGIC;
           axi4s_tdata : in STD_LOGIC_VECTOR (data_width-1 downto 0);
           axi4s_tvalid : in STD_LOGIC;
           axi4s_tready : out STD_LOGIC;
           axi4s_tlast : in STD_LOGIC;
           axi4s_tuser : in STD_LOGIC;
           vga_hsync : out STD_LOGIC;
           vga_vsync : out STD_LOGIC;
           vga_red : out STD_LOGIC_VECTOR (3 downto 0);
           vga_green : out STD_LOGIC_VECTOR (3 downto 0);   
           vga_blue : out STD_LOGIC_VECTOR (3 downto 0));
    end component;       
	component axi4s_driver is
        generic (
            G_FILE_PATH         : string  := "sample_in_b.txt";
            G_DATA_WIDTH        : integer := data_width_c;
            G_INIT_DELAY        : integer := 10;
            G_TLAST_END_OF_LINE : boolean := true;
            G_LOOP_COUNT        : integer := 0   -- 0 = boucle infinie
        );
        Port ( 
            clk_i : in STD_LOGIC;
            rst_i : in STD_LOGIC;
            m_tvalid : out STD_LOGIC;
            m_tdata : out STD_LOGIC_VECTOR (data_width_c-1 downto 0);
            m_tlast : out STD_LOGIC; 
            m_tuser  : out std_logic;
            m_tready : in STD_LOGIC;
            done_o : out STD_LOGIC;
            frame_cnt_o : out integer;
            pixel_cnt_o : out integer);
        end component;

	begin
	dut: axi4s_to_vga
        port map (
            clk => clk,
            resetn => resetn,
            axi4s_tdata => axi4s_tdata,
            axi4s_tvalid => axi4s_tvalid,
            axi4s_tready => axi4s_tready,
            axi4s_tlast => axi4s_tlast,
            axi4s_tuser => axi4s_tuser,
            vga_hsync => vga_hsync, 
            vga_vsync => vga_vsync,
            vga_red => vga_red, 
            vga_green => vga_green,
            vga_blue => vga_blue
            );  
    axi4s_driver_r : axi4s_driver
        generic map(
            G_FILE_PATH => "image_alea_r.txt",
            G_DATA_WIDTH =>8
       )      
        port map (
            clk_i => clk,
            rst_i => reset,
            m_tvalid => axi4s_tvalid,
            m_tdata => axi4s_tdata(23 downto 16),
            m_tlast => axi4s_tlast, 
            m_tuser => axi4s_tuser,
            m_tready => axi4s_tready,
            done_o => open,
            frame_cnt_o => open,
            pixel_cnt_o => open
            );
    axi4s_driver_b : axi4s_driver
        generic map(
            G_FILE_PATH => "image_alea_b.txt",
            G_DATA_WIDTH =>8
        )        
        port map (
            clk_i => clk,
            rst_i => reset,
            m_tvalid => axi4s_tvalid,
            m_tdata => axi4s_tdata(15 downto 8),
            m_tlast => axi4s_tlast, 
            m_tuser => axi4s_tuser,
            m_tready => axi4s_tready,
            done_o => open,
            frame_cnt_o => open,
            pixel_cnt_o => open
            );
    axi4s_driver_g : axi4s_driver
        generic map(
            G_FILE_PATH => "image_alea_g.txt",
            G_DATA_WIDTH =>8
       )
        port map (
            clk_i => clk,
            rst_i => reset,
            m_tvalid => axi4s_tvalid,
            m_tdata => axi4s_tdata(7 downto 0),
            m_tlast => axi4s_tlast, 
            m_tuser => axi4s_tuser,
            m_tready => axi4s_tready,
            done_o => open,
            frame_cnt_o => open,
            pixel_cnt_o => open
            );		
	--Simulation du signal d'horloge en continue
	process
    begin
		wait for hp;
		clk <= not clk;
	end process;

	main: process
    begin
        -- demarrage au reset
        resetn <= '0';
        reset <= '1';
        wait for 100ns;
        resetn <= '1';
        reset <= '0';      
         wait;
 	end process;

	count: process
	variable line_count : integer :=0;
	variable pix_count : integer :=0;
	variable pix_report : integer :=0;
    begin
        wait until rising_edge (clk) and axi4s_tuser = '1'and axi4s_tvalid = '1'and axi4s_tready = '1'; 
        line_count :=0;  
        pix_count := 1; 
        loop
           wait until rising_edge (clk) ;  
           if axi4s_tready = '1' and axi4s_tvalid = '1' then 
                if axi4s_tuser = '1'then 
                    if line_count = 480 then 
                        report integer'image(line_count)&" lignes de "& integer'image(pix_report) &  "pixels dans la frame transmises "   severity note;
                    else 
                        report " ERREUR nb de ligne dans la frame :  " & integer'image(pix_report)    severity error;
                    end if;              
                    line_count := 0;
                    pix_count := 1;
                else 
                    pix_count:= pix_count+1;
                    if axi4s_tlast = '1' then 
                        line_count := line_count +1;
                        pix_report := pix_count;
                       if pix_count = 640 then 
                            --report integer'image(pix_count) & "pixels compt�s sur ligne " & integer'image(line_count)   severity note;
                        else 
                            pix_report := pix_count;
                            report " ERREUR" & integer'image(pix_count) &"pixels compt�s sur la ligne " & integer'image(line_count) severity error;
                        end if;                    
                        pix_count :=0;
                    end if;
                end if;
            end if;
        end loop;
    end process;
        
             


	
end behavioral;