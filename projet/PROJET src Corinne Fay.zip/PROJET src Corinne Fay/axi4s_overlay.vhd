-- modif history
-- 1.1 remove condition on tuser for changing signal

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;


entity axi4s_overlay is
    generic (
        DATA_WIDTH : integer := 24
    );
    Port (
        clk          : in  STD_LOGIC;
        resetn       : in  STD_LOGIC;
        -- selecteur de flux
        add_filter          : in  STD_LOGIC;
        -- AXI4-Stream input 1 : filter
        axi4s_i1_tdata  : in STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
        axi4s_i1_tvalid : in STD_LOGIC;
        axi4s_i1_tready : out  STD_LOGIC;
        axi4s_i1_tlast  : in STD_LOGIC;
        axi4s_i1_tuser  : in STD_LOGIC;
       -- AXI4-Stream input 2 : direct
        axi4s_i2_tdata  : in STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
        axi4s_i2_tvalid : in STD_LOGIC;
        axi4s_i2_tready : out  STD_LOGIC;
        axi4s_i2_tlast  : in STD_LOGIC;
        axi4s_i2_tuser  : in STD_LOGIC;
        -- AXI4-Stream Video output
        axi4s_o_tdata  : out STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
        axi4s_o_tvalid : out STD_LOGIC;
        axi4s_o_tready : in  STD_LOGIC;
        axi4s_o_tlast  : out STD_LOGIC;
        axi4s_o_tuser  : out STD_LOGIC
        );
end axi4s_overlay;

architecture Behavioral of axi4s_overlay is
    
begin  
    axi4s_i1_tready <= axi4s_o_tready and axi4s_i2_tvalid;
    axi4s_i2_tready <= axi4s_o_tready and axi4s_i1_tvalid;
    axi4s_o_tdata  <=  axi4s_i2_tdata when add_filter = '0' or axi4s_i1_tdata = (axi4s_i1_tdata'range => '0') 
                else axi4s_i1_tdata ;
    axi4s_o_tvalid  <= axi4s_i1_tvalid and axi4s_i2_tvalid;
    axi4s_o_tlast  <= axi4s_i1_tlast;
    axi4s_o_tuser  <= axi4s_i1_tuser ;

end Behavioral;