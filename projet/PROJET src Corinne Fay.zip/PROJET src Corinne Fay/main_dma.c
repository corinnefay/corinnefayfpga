/******************************************************************************
* Copyright (C) 2002 - 2021 Xilinx, Inc.  All rights reserved.
* SPDX-License-Identifier: MIT
******************************************************************************/

/*****************************************************************************/
/**
* @file xgpio_example.c
*
* This file contains a design example using the AXI GPIO driver (XGpio) and
* hardware device.  It only uses channel 1 of a GPIO device and assumes that
* the bit 0 of the GPIO is connected to the LED on the HW board.
*
*
* <pre>
* MODIFICATION HISTORY:
*
* Ver   Who  Date     Changes
* ----- ---- -------- -----------------------------------------------
* 1.00a rmm  03/13/02 First release
* 1.00a rpm  08/04/03 Removed second example and invalid macro calls
* 2.00a jhl  12/15/03 Added support for dual channels
* 2.00a sv   04/20/05 Minor changes to comply to Doxygen and coding guidelines
* 3.00a ktn  11/20/09 Minor changes as per coding guidelines.
* 4.1   lks  11/18/15 Updated to use canonical xparameters and
*		      clean up of the comments and code for CR 900381
* 4.3   sk   09/29/16 Modified the example to make it work when LED_bits are
*                     configured as an output. CR# 958644
*       ms   01/23/17 Added xil_printf statement in main function to
*                     ensure that "Successfully ran" and "Failed" strings
*                     are available in all examples. This is a fix for
*                     CR-965028.
* 4.5  sne   06/12/19 Fixed IAR compiler warning.
*
* </pre>
******************************************************************************/

/***************************** Include Files *********************************/

#include "xparameters.h"
#include "xuartps.h"
#include "xil_printf.h"
#include "axis_harris_register.h"
#include "axis4a_dma2_register.h"
#include "ff.h" // gestion fichier carte sd
#include "xaxis_switch.h"
#include "xil_io.h"
#include "xil_cache.h"
/************************** Constant Definitions *****************************/
/******************************************************************/
#define UART_DEVICE_ID                  XPAR_XUARTPS_0_DEVICE_ID


#define START      1
#define STOP       0

#define WIDTH       640
#define HEIGHT      480
#define FRAME_SIZE  (WIDTH * HEIGHT * 3)

#define HARRIS_LEVEL      20

//  DMA registers address
#define DMA_REG_BASE    XPAR_AXIS4A_DMA2_REGISTER_0_S00_AXI_BASEADDR

#define DMA_REG_IMAGE_START AXIS4A_DMA2_REGISTER_S00_AXI_SLV_REG0_OFFSET
#define DMA_REG_IMAGE_W     AXIS4A_DMA2_REGISTER_S00_AXI_SLV_REG1_OFFSET
#define DMA_REG_IMAGE_H     AXIS4A_DMA2_REGISTER_S00_AXI_SLV_REG2_OFFSET
#define DMA_REG_IMAGE_LO    AXIS4A_DMA2_REGISTER_S00_AXI_SLV_REG3_OFFSET
#define DMA_REG_IMAGE_HI    AXIS4A_DMA2_REGISTER_S00_AXI_SLV_REG4_OFFSET
#define DMA_REG_STATUS      AXIS4A_DMA2_REGISTER_S00_AXI_SLV_REG5_OFFSET

//  harris registers address
#define HARRIS_REG_BASE    XPAR_AXIS_HARRIS_REGISTER_0_S00_AXI_BASEADDR

#define HARRIS_REG_MAX AXIS_HARRIS_REGISTER_S00_AXI_SLV_REG0_OFFSET 
#define HARRIS_REG_MAX_X AXIS_HARRIS_REGISTER_S00_AXI_SLV_REG1_OFFSET 
#define HARRIS_REG_MAX_Y AXIS_HARRIS_REGISTER_S00_AXI_SLV_REG2_OFFSET 
#define HARRIS_REG_LEVEL AXIS_HARRIS_REGISTER_S00_AXI_SLV_REG3_OFFSET 
#define HARRIS_REG_OVERLAY AXIS_HARRIS_REGISTER_S00_AXI_SLV_REG4_OFFSET 
//  switch  registers address
//#define SWITCH_REG_BASE    XPAR_AXIS_SWITCH_0_BASEADDR


#define DDR_BASE_ADDRLO	0x01000000
#define DDR_BASE_ADDRHI	0x00000000


XUartPs Uart_Ps;

//  globals for FatFs
static FATFS fatfs;
FIL file;
FRESULT res;
UINT bytes_read;


XAxis_Switch AxisSwitch;

int init_switch(void)
{
    XAxis_Switch_Config *Config;

    /* V�rifie le nom exact dans xparameters.h */
    Config = XAxisScr_LookupConfig(XPAR_AXIS_SWITCH_0_DEVICE_ID);

    if (Config == NULL)
        return XST_FAILURE;

    return XAxisScr_CfgInitialize(&AxisSwitch, Config, Config->BaseAddress);
}
void choisir_entree(u8 entree)
{
    XAxisScr_RegUpdateDisable(&AxisSwitch);
    /* sortie M00_AXIS connect�e � l'entr�e s�lectionn�e */
    XAxisScr_MiPortEnable(&AxisSwitch, 0, entree);

    /* Appliquer le nouveau routage */
    XAxisScr_RegUpdateEnable(&AxisSwitch);
}
void change_entree(u8 entree)
{
    XAxisScr_RegUpdateDisable(&AxisSwitch);
    XAxisScr_MiPortDisable(&AxisSwitch, 0);
    /* sortie M00_AXIS connect�e � l'entr�e s�lectionn�e */
    XAxisScr_MiPortEnable(&AxisSwitch, 0, entree);

    /* Appliquer le nouveau routage */
    XAxisScr_RegUpdateEnable(&AxisSwitch);
}

int main(void)
{
	u32 dma_read;
	XUartPs_Config *Config;
	// UART config
	Config = XUartPs_LookupConfig(UART_DEVICE_ID);
	 XUartPs_CfgInitialize(&Uart_Ps, Config, Config->BaseAddress);
		XUartPs_SetBaudRate(&Uart_Ps, 115200);
	// SD cart
	   // 1. Monter le syst�me de fichiers de la carte SD
		xil_printf("SD cart loading...\r\n");
	    res = f_mount(&fatfs, "0:/", 1);
	    xil_printf("Carte SD montee avec succes !\n\r");
	    // 2. Ouvrir le fichier image.bin (en mode lecture seule)
	    res = f_open(&file, "image.bin", FA_READ);
	    xil_printf("Fichier image.bin trouve.\n\r");
	    // 3. Lire le fichier et l'�crire directement � l'adresse DDR_IMAGE_ADDR
	    // Note : On utilise un pointeur vers l'adresse DDR comme destination pour FatFs
	    res = f_read(&file, (void*)DDR_BASE_ADDRLO, f_size(&file), &bytes_read);


	    xil_printf("Succes ! %d octets charges en DDR a l'adresse 0x%08X\n\r", bytes_read, DDR_BASE_ADDRLO);

	    // 4. Fermer le fichier
	    f_close(&file);

    xil_printf("Image charg�e en DDR puis appuie sur une touche...\r\n");
    inbyte();

   xil_printf("Demarrage DMA\r\n");
    // DMA image settings
   Xil_Out32(DMA_REG_BASE+ DMA_REG_IMAGE_W, WIDTH);
    Xil_Out32(DMA_REG_BASE+ DMA_REG_IMAGE_H, HEIGHT);
    Xil_Out32(DMA_REG_BASE+ DMA_REG_IMAGE_LO, DDR_BASE_ADDRLO);
    Xil_Out32(DMA_REG_BASE+ DMA_REG_IMAGE_HI, DDR_BASE_ADDRHI);
    xil_printf("STATUS DMA : IMAGE_W  = %d\r\n", AXIS4A_DMA2_REGISTER_mReadReg(DMA_REG_BASE, DMA_REG_IMAGE_W));
    xil_printf("STATUS DMA :IMAGE_H  = %d\r\n", AXIS4A_DMA2_REGISTER_mReadReg(DMA_REG_BASE, DMA_REG_IMAGE_H));
    xil_printf("STATUS DMA :IMAGE_LO = 0x%08x\r\n",AXIS4A_DMA2_REGISTER_mReadReg(DMA_REG_BASE, DMA_REG_IMAGE_LO));
    xil_printf("STATUS DMA :IMAGE_HI = 0x%08x\r\n",AXIS4A_DMA2_REGISTER_mReadReg(DMA_REG_BASE, DMA_REG_IMAGE_HI));
    // DMA START
    Xil_Out32(DMA_REG_BASE + DMA_REG_IMAGE_START, START);

    dma_read = Xil_In32(DMA_REG_BASE+ DMA_REG_STATUS);
		xil_printf("STATUS DMA :   = 0x%08x\r\n", dma_read);


	 //init du axis switch
	    Xil_Out32(HARRIS_REG_BASE + HARRIS_REG_OVERLAY, 0x00000010);

	    init_switch();
	    choisir_entree(1);
	     xil_printf("Affichage du pattern ..\r\n");

	  // config harris

     Xil_Out32(HARRIS_REG_BASE + HARRIS_REG_LEVEL, HARRIS_LEVEL);
     xil_printf("Appuie sur une touche pour afficher le filtre niveau 20 ..\r\n");
     inbyte();
        Xil_Out32(HARRIS_REG_BASE + HARRIS_REG_OVERLAY, 0x00000011);
        xil_printf("MAX filter  = %d\r\n",AXIS_HARRIS_REGISTER_mReadReg(HARRIS_REG_BASE, HARRIS_REG_MAX));
        xil_printf("colonne du max  = %d\r\n", AXIS_HARRIS_REGISTER_mReadReg(HARRIS_REG_BASE, HARRIS_REG_MAX_X));
        xil_printf("ligne du max = %d\r\n",AXIS_HARRIS_REGISTER_mReadReg(HARRIS_REG_BASE, HARRIS_REG_MAX_Y));

         xil_printf("Appuie sur une touche pour afficher le filtre niveau 5 ..\r\n");
        inbyte();
        	Xil_Out32(HARRIS_REG_BASE + HARRIS_REG_LEVEL, 5);
           xil_printf("MAX filter  = %d\r\n",AXIS_HARRIS_REGISTER_mReadReg(HARRIS_REG_BASE, HARRIS_REG_MAX));
           xil_printf("colonne du max  = %d\r\n", AXIS_HARRIS_REGISTER_mReadReg(HARRIS_REG_BASE, HARRIS_REG_MAX_X));
           xil_printf("ligne du max = %d\r\n",AXIS_HARRIS_REGISTER_mReadReg(HARRIS_REG_BASE, HARRIS_REG_MAX_Y));
           xil_printf("Appuie sur une touche pour afficher le filtre niveau 25 ..\r\n");
          inbyte();
          	Xil_Out32(HARRIS_REG_BASE + HARRIS_REG_LEVEL, 25);
             xil_printf("MAX filter  = %d\r\n",AXIS_HARRIS_REGISTER_mReadReg(HARRIS_REG_BASE, HARRIS_REG_MAX));
             xil_printf("colonne du max  = %d\r\n", AXIS_HARRIS_REGISTER_mReadReg(HARRIS_REG_BASE, HARRIS_REG_MAX_X));
             xil_printf("ligne du max = %d\r\n",AXIS_HARRIS_REGISTER_mReadReg(HARRIS_REG_BASE, HARRIS_REG_MAX_Y));

       //xil_printf("Appuie sur une touche pour afficher le pattern ...\r\n");
      //  inbyte();
      //  change_entree(1);
         xil_printf("Appuie sur une touche pour eteindre le filtre ...\r\n");
         inbyte();
            Xil_Out32(HARRIS_REG_BASE + HARRIS_REG_OVERLAY, 0x00000010);
      xil_printf("Appuie sur une touche pour afficher le filtre ...\r\n");
       inbyte();
          Xil_Out32(HARRIS_REG_BASE + HARRIS_REG_OVERLAY, 0x00000011);
          xil_printf("MAX filter  = %d\r\n",AXIS_HARRIS_REGISTER_mReadReg(HARRIS_REG_BASE, HARRIS_REG_MAX));
          xil_printf("colonne du max  = %d\r\n", AXIS_HARRIS_REGISTER_mReadReg(HARRIS_REG_BASE, HARRIS_REG_MAX_X));
          xil_printf("ligne du max = %d\r\n",AXIS_HARRIS_REGISTER_mReadReg(HARRIS_REG_BASE, HARRIS_REG_MAX_Y));

          xil_printf("Test Termin�.\r\n");


	return 0;
}
int InitUart(u16 DeviceId)
{
	u8 HelloWorld[] = "Hello World";
	int SentCount = 0;
	int Status;
	XUartPs_Config *Config;

	/*
	 * Initialize the UART driver so that it's ready to use
	 * Look up the configuration in the config table and then initialize it.
	 */
	Config = XUartPs_LookupConfig(DeviceId);
	if (NULL == Config) {
		return XST_FAILURE;
	}

	Status = XUartPs_CfgInitialize(&Uart_Ps, Config, Config->BaseAddress);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	XUartPs_SetBaudRate(&Uart_Ps, 115200);

	while (SentCount < (sizeof(HelloWorld) - 1)) {
		/* Transmit the data */
		SentCount += XUartPs_Send(&Uart_Ps,
					   &HelloWorld[SentCount], 1);
	}

	return SentCount;
}
