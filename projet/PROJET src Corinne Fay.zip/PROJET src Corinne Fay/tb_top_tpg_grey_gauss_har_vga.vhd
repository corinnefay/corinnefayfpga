library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_top_tpg_grey_gauss_har_vga is
end tb_top_tpg_grey_gauss_har_vga;

architecture Behavioral of tb_top_tpg_grey_gauss_har_vga is
    constant DATA_WIDTH : integer := 24;
    signal clk_inpll         : std_logic := '0';
    signal resetn       : std_logic := '1';
    signal filter_sel : std_logic := '0';
    --signal harris_level : STD_LOGIC_VECTOR(31 downto 0);
    --signal max_harris   : std_logic_vector (31 downto 0);
    --signal max_harris_x  : std_logic_vector (31 downto 0);
    --signal max_harris_y: std_logic_vector (31 downto 0);
    signal vga_hsync : STD_LOGIC := '0';
    signal vga_vsync : STD_LOGIC := '0';
    signal vga_red : STD_LOGIC_VECTOR (3 downto 0);
    signal vga_blue : STD_LOGIC_VECTOR (3 downto 0);
    signal vga_green : STD_LOGIC_VECTOR (3 downto 0);

	-- Les constantes suivantes permette de definir la frequence de l'horloge 
	constant hp : time := 4 ns;      --demi periode de 5ns
	constant period : time := 2*hp;  --periode de 10ns, soit une frequence de 125MHz

	component top_tpg_grey_gauss_har_vga is
		port (
            clk_inpll          : in  STD_LOGIC;
            resetn       : in  STD_LOGIC;
            filter_sel          : in  STD_LOGIC;
            --harris_level : in STD_LOGIC_VECTOR(31 downto 0);
            --max_harris   : out std_logic_vector (31 downto 0);
            --max_harris_x  : out std_logic_vector (31 downto 0);
            --max_harris_y: out std_logic_vector (31 downto 0);
            vga_red : out  STD_LOGIC_VECTOR (3 downto 0);
            vga_blue : out  STD_LOGIC_VECTOR (3 downto 0);
            vga_green : out  STD_LOGIC_VECTOR (3 downto 0);
            vga_hsync : out  STD_LOGIC;    
            vga_vsync : out  STD_LOGIC);          
	end component;

begin
	dut: top_tpg_grey_gauss_har_vga

        port map (
            clk_inpll => clk_inpll,
            resetn => resetn,
            filter_sel => filter_sel,
            --harris_level =>harris_level,
            --max_harris   =>max_harris,
            --max_harris_x  =>max_harris_x,
            --max_harris_y=>max_harris_y,
            vga_red => vga_red,
            vga_blue => vga_blue, 
            vga_green => vga_green,
            vga_hsync => vga_hsync,
            vga_vsync => vga_vsync
		
        );
	--Simulation du signal d'horloge en continue
	process
    begin
		wait for hp;
		clk_inpl <= not clk_inpll;
	end process;
	process
    begin
        resetn <= '0';
        wait for 5us;
        resetn <= '1';
        --harris_level(31 downto 8) <= (others => '0');
        --harris_level(7 downto 0) <=(others => '0');
        --harris_level(7 downto 0) <="01111101";
        filter_sel <= '0';

        wait for 1ms;
        --filter_sel <= '1';

        wait;
	end process;    
end Behavioral;
