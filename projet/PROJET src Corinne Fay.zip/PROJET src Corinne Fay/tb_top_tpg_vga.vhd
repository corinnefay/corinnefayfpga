library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_top_tpg_vga is
end tb_top_tpg_vga;

architecture Behavioral of tb_top_tpg_vga is
    constant DATA_WIDTH : integer := 24;
    signal clk_in         : std_logic := '0';
    signal resetn       : std_logic := '1';
    signal filter_sel  : std_logic;
    signal vga_hsync : STD_LOGIC := '0';
    signal vga_vsync : STD_LOGIC := '0';
    signal vga_red : STD_LOGIC_VECTOR (3 downto 0);
    signal vga_blue : STD_LOGIC_VECTOR (3 downto 0);
    signal vga_green : STD_LOGIC_VECTOR (3 downto 0);

	-- Les constantes suivantes permette de definir la frequence de l'horloge 
	constant hp : time := 4 ns;      --demi periode de 5ns
	constant period : time := 2*hp;  --periode de 10ns, soit une frequence de 125MHz

	component top_tpg_vga is
		port (
            clk_in          : in  STD_LOGIC;
            resetn       : in  STD_LOGIC;
            filter_sel  : in std_logic;
            vga_red : out  STD_LOGIC_VECTOR (3 downto 0);
            vga_blue : out  STD_LOGIC_VECTOR (3 downto 0);
            vga_green : out  STD_LOGIC_VECTOR (3 downto 0);
            vga_hsync : out  STD_LOGIC;    
            vga_vsync : out  STD_LOGIC);          
	end component;

begin
	dut: top_tpg_vga

        port map (
            clk_in => clk_in,
            resetn => resetn,
            filter_sel=>filter_sel,
            vga_red => vga_red,
            vga_blue => vga_blue, 
            vga_green => vga_green,
            vga_hsync => vga_hsync,
            vga_vsync => vga_vsync
		
        );
	--Simulation du signal d'horloge en continue
	process
    begin
		wait for hp;
		clk_in <= not clk_in;
	end process;


	process
    begin
        -- filter_sel pas utilis� pour ce tb
        filter_sel <= '0';
        resetn <= '0';
        wait for 100us;
        resetn <= '1';

 
        wait;
	end process;  
  
end Behavioral;
