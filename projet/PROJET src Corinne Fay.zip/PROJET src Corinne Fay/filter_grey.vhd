library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;


entity filter_grey  is
    generic (
        DATA_WIDTH : integer := 24;
        COLOR_WIDTH : integer :=8
    );
    Port (
        clk          : in  STD_LOGIC;
        resetn       : in  STD_LOGIC;
        -- AXI4-Stream Video input
        axi4s_i_tdata  : in STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
        axi4s_i_tvalid : in STD_LOGIC;
        axi4s_i_tready : out  STD_LOGIC;
        axi4s_i_tlast  : in STD_LOGIC;
        axi4s_i_tuser  : in STD_LOGIC;
        -- AXI4-Stream Video output
        axi4s_o_tdata  : out STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
        axi4s_o_tvalid : out STD_LOGIC;
        axi4s_o_tready : in  STD_LOGIC;
        axi4s_o_tlast  : out STD_LOGIC;
        axi4s_o_tuser  : out STD_LOGIC
        );
end filter_grey;

architecture Behavioral of filter_grey is
    signal red   : unsigned(COLOR_WIDTH-1 downto 0);    
    signal green : unsigned(COLOR_WIDTH-1 downto 0);
    signal blue  : unsigned(COLOR_WIDTH-1 downto 0);
    signal add  : unsigned(COLOR_WIDTH+1 downto 0);
    signal mult  : unsigned(2*COLOR_WIDTH-1 downto 0);
    signal grey  : unsigned(COLOR_WIDTH-1 downto 0);
    signal reg1_tdata : std_logic_vector(DATA_WIDTH-1 downto 0);
    signal reg1_tuser : std_logic := '0';
    signal reg1_tlast: std_logic := '0';
    signal reg1_empty: std_logic := '1';
    signal reg1_dispo: std_logic := '1';
    signal reg2_tdata : std_logic_vector(DATA_WIDTH-1 downto 0);
    signal reg2_tuser : std_logic := '0';
    signal reg2_tlast: std_logic := '0';
    signal reg2_empty: std_logic := '1';
    signal reg2_dispo: std_logic := '1';

    signal handshake_in : std_logic :='0';
    signal handshake_out : std_logic :='0';
    --signal handshakes : std_logic_vector(1 downto 0);
    signal axi4s_i_tready_b : std_logic :='0';
    signal axi4s_o_tvalid_b : std_logic :='0';


    
 
begin

    -- calcul du filtrage
    red <= unsigned(axi4s_i_tdata(DATA_WIDTH-1 downto DATA_WIDTH-COLOR_WIDTH));
    green <= unsigned(axi4s_i_tdata(DATA_WIDTH-COLOR_WIDTH-1 downto DATA_WIDTH-2*COLOR_WIDTH));
    blue <= unsigned(axi4s_i_tdata(DATA_WIDTH-2*COLOR_WIDTH-1 downto DATA_WIDTH-3*COLOR_WIDTH));
    add <= resize (red,COLOR_WIDTH+2) + resize(green,COLOR_WIDTH+2) + resize(blue,COLOR_WIDTH+2);    
    mult <= resize(add*85,2*COLOR_WIDTH);    
    grey <= mult(15 downto 8);

    -- signaux axi stream
    
    axi4s_i_tready_b <= reg1_dispo;
    axi4s_i_tready <=  axi4s_i_tready_b;
    axi4s_o_tvalid_b <= not reg2_empty;
    axi4s_o_tvalid <= axi4s_o_tvalid_b;
    axi4s_o_tdata <= reg2_tdata; 
    axi4s_o_tlast <= reg2_tlast;
    axi4s_o_tuser <= reg2_tuser; 
    reg2_dispo <= reg2_empty or axi4s_o_tready;
    reg1_dispo <= reg1_empty or reg2_dispo;

    handshake_in <= axi4s_i_tvalid and axi4s_i_tready_b; 
    handshake_out <= axi4s_o_tvalid_b and axi4s_o_tready;
    --dacalage a deux registre du signal axi stream pour l'indepandance de flus d'entr�e et du flux de sortie
    -- on doit pourvoir stocker les data dans un registre pour s'assurer de rien perdre
    -- et assurer la transmission sans trou sur l'etage suivant
    axireg: process(clk, resetn)
    begin 
        if resetn = '0' then 
            reg1_tdata <= (others =>'0');
            reg1_tuser <= '0';
            reg1_tlast<= '0';
            reg1_empty<= '1';
            reg2_tdata <= (others =>'0');
            reg2_tuser <= '0';
            reg2_tlast<= '0';
            reg2_empty<= '1';
        elsif rising_edge(clk) then
            -- registre de sortie R2
            -- le registre est plein et pret a envoyer la data
            if reg2_dispo = '1' then 
                if reg1_empty = '0' then
                    -- on regarde R1 si plein on transmet R1 dans R2
                    reg2_tdata <= reg1_tdata;
                    reg2_tlast <= reg1_tlast;
                    reg2_tuser <= reg1_tuser; 
                    reg2_empty <= '0';
                else
                    -- rien � mettre dans R2
                    reg2_empty <= '1';
                end if;
            end if;
            -- registre R1
            if reg1_dispo = '1' then
                if handshake_in = '1' then
                    reg1_tdata(DATA_WIDTH-1 downto DATA_WIDTH-COLOR_WIDTH) <= std_logic_vector(grey);
                    reg1_tdata(DATA_WIDTH-COLOR_WIDTH-1 downto DATA_WIDTH-2*COLOR_WIDTH) <= std_logic_vector(grey);
                    reg1_tdata(DATA_WIDTH-2*COLOR_WIDTH-1 downto DATA_WIDTH-3*COLOR_WIDTH) <= std_logic_vector(grey); 
                    reg1_tlast <= axi4s_i_tlast;
                    reg1_tuser <= axi4s_i_tuser;
                    reg1_empty <= '0';
                 else
                     reg1_empty <= '1';
                 end if;
            end if;
          end if;
    end process;  


end behavioral; 

