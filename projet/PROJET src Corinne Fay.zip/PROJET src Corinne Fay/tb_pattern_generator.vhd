library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_pattern_generator is
end tb_pattern_generator;

architecture Behavioral of tb_pattern_generator is
    constant DATA_WIDTH : integer := 24;
    signal clk         : std_logic := '0';
    signal resetn       : std_logic := '1';
    signal reset : std_logic  :='0';
    signal done : std_logic :='0';
    signal img_cnt : integer;
    signal line_cnt : integer;
    signal pixel_cnt : integer;
    signal pattern_en : std_logic := '0';
    signal axi4s_tdata  :  STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
    signal axi4s_tvalid :  STD_LOGIC;
    signal axi4s_tready :   STD_LOGIC;
    signal axi4s_tlast  :  STD_LOGIC;
    signal axi4s_tuser  :  STD_LOGIC;
	-- Les constantes suivantes permette de definir la frequence de l'horloge 
	constant hp : time := 20 ns;      --demi periode de 5ns
	constant period : time := 2*hp;  --periode de 10ns, soit une frequence de 25MHz

	component pattern_generator is
        generic (
            DATA_WIDTH : integer := 24
        );
		port (
            clk          : in  STD_LOGIC;
            resetn       : in  STD_LOGIC;
            pattern_en  : in STD_LOGIC;
            -- AXI4-Stream Video
            axi4s_tdata  : out STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_tvalid : out STD_LOGIC;
            axi4s_tready : in  STD_LOGIC;
            axi4s_tlast  : out STD_LOGIC;
            axi4s_tuser  : out STD_LOGIC
             );
	end component;
    component axi4s_monitor is
    generic (
        G_FILE_BASENAME : string  := "stream_r_out";
        G_DATA_WIDTH    : integer := 8;
        G_IMG_WIDTH     : integer := 640;
        G_IMG_HEIGHT    : integer := 480;
        G_NB_IMAGES     : integer := 1;
        G_TIMEOUT_CY    : integer := 10000;
        G_SYNC_ON_SOF   : boolean := false
    );
    port (
        clk_i    : in  std_logic;
        rst_i    : in  std_logic;    -- reset actif haut
        s_tvalid : in  std_logic;
        s_tdata  : in  std_logic_vector(G_DATA_WIDTH-1 downto 0);
        s_tlast  : in  std_logic;
        s_tuser  : in  std_logic := '0';   -- SOF : '1' sur le premier pixel de trame
        s_tready : out std_logic;
        done_o      : out std_logic;  -- '1' apres capture de toutes les images
        img_cnt_o   : out integer;    -- indice de l'image en cours
        line_cnt_o  : out integer;    -- lignes capturees dans l'image courante
        pixel_cnt_o : out integer     -- pixels totaux captures
    );
	end component;
begin
	dut: pattern_generator

        port map (
            clk => clk,
            resetn => resetn,
            pattern_en => pattern_en,
            axi4s_tdata => axi4s_tdata,
            axi4s_tvalid => axi4s_tvalid,
            axi4s_tready => axi4s_tready,
            axi4s_tlast => axi4s_tlast,
            axi4s_tuser => axi4s_tuser
			
        );
    axi4s_monitor_r :  axi4s_monitor
        generic map(
            G_FILE_BASENAME => "stream_r_out"
        )
        port map(
            clk_i    => clk,
            rst_i   => reset,  
            s_tvalid => axi4s_tvalid,
            s_tdata  => axi4s_tdata(23 downto 16),
            s_tlast  => axi4s_tlast,
            s_tuser  => axi4s_tuser,   
            s_tready => axi4s_tready,
            done_o      =>open,  
            img_cnt_o   =>open,  
            line_cnt_o  =>open,   
            pixel_cnt_o =>open   
        );
    axi4s_monitor_g :  axi4s_monitor
        generic map (
            G_FILE_BASENAME => "stream_g_out"
        )
        port map(
            clk_i    => clk,
            rst_i   => reset,  
            s_tvalid => axi4s_tvalid,
            s_tdata  => axi4s_tdata(15 downto 8),
            s_tlast  => axi4s_tlast,
            s_tuser  => axi4s_tuser,   
            s_tready => axi4s_tready,
            done_o      =>open,  
            img_cnt_o   =>open,  
            line_cnt_o  =>open,   
            pixel_cnt_o =>open   
        );
    axi4s_monitor_b :  axi4s_monitor
        generic map(
            G_FILE_BASENAME => "stream_b_out"
        )
        port map(
            clk_i    => clk,
            rst_i   => reset,    
            s_tvalid => axi4s_tvalid,
            s_tdata  => axi4s_tdata(7 downto 0),
            s_tlast  => axi4s_tlast,
            s_tuser  => axi4s_tuser,   
            s_tready => axi4s_tready,
            done_o      =>done,
            img_cnt_o   =>img_cnt,
            line_cnt_o  =>line_cnt,   
            pixel_cnt_o =>pixel_cnt   
        );
	--Simulation du signal d'horloge en continue
	process
    begin
		wait for hp;
		clk <= not clk;
	end process;
	
	main: process
    begin
        -- demarrage au reset
        resetn <= '0';
        reset <= '1';
        wait for 100ns;
        resetn <= '1';
        reset <= '0';      
        wait for 100ns;
        -- demarrage du pattern
        pattern_en <='1';
        wait ;

	end process;  
	
	
	
	count: process
	variable line_count : integer :=0;
	variable pix_count : integer :=0;
	variable pix_report : integer :=0;
    begin
        wait until rising_edge (clk) and axi4s_tuser = '1'and axi4s_tvalid = '1'and axi4s_tready = '1'; 
        line_count :=0;  
        pix_count := 1; 
        loop
           wait until rising_edge (clk) ;  
           if axi4s_tready = '1' and axi4s_tvalid = '1' then 
                if axi4s_tuser = '1'then 
                    if line_count = 480 then 
                        report integer'image(line_count)&" lignes de "& integer'image(pix_report) &  "pixels dans la frame transmises "   severity note;
                    else 
                        report " ERREUR nb de ligne dans la frame :  " & integer'image(pix_report)    severity error;
                    end if;              
                    line_count := 0;
                    pix_count := 1;
                else 
                    pix_count:= pix_count+1;
                    if axi4s_tlast = '1' then 
                        line_count := line_count +1;
                        pix_report := pix_count;
                       if pix_count = 640 then 
                            --report integer'image(pix_count) & "pixels compt?s sur ligne " & integer'image(line_count)   severity note;
                        else 
                            pix_report := pix_count;
                            report " ERREUR" & integer'image(pix_count) &"pixels compt?s sur la ligne " & integer'image(line_count) severity error;
                        end if;                    
                        pix_count :=0;
                    end if;
                end if;
            end if;
        end loop;
    end process;
          
end Behavioral;
