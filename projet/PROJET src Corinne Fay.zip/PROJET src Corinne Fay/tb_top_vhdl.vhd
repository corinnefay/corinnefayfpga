library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity tb_top_vhdl is
end tb_top_vhdl;

architecture Behavioral of tb_top_vhdl is
    constant DATA_WIDTH : integer := 24;
    signal clk_in         : std_logic := '0';
    signal reset       : std_logic := '1';
    signal add_filter : std_logic := '0';
    signal vga_hsync : STD_LOGIC := '0';
    signal vga_vsync : STD_LOGIC := '0';
    signal vga_red : STD_LOGIC_VECTOR (3 downto 0);
    signal vga_blue : STD_LOGIC_VECTOR (3 downto 0);
    signal vga_green : STD_LOGIC_VECTOR (3 downto 0);
    signal fifo_almost_empty :  STD_LOGIC;
    signal fifo_almost_full : STD_LOGIC;
	-- Les constantes suivantes permette de definir la frequence de l'horloge 
	constant hp : time := 4 ns;      --demi periode de 5ns
	constant period : time := 2*hp;  --periode de 10ns, soit une frequence de 125MHz

	component top_vhdl is
		port (
            clk_in          : in  STD_LOGIC;
             reset      : in std_logic;
            reset_clk  : in std_logic;
                add_filter          : in  STD_LOGIC;
            fifo_almost_empty_reg : out STD_LOGIC;
            fifo_almost_full_reg : out STD_LOGIC;
            vga_red : out  STD_LOGIC_VECTOR (3 downto 0);
            vga_blue : out  STD_LOGIC_VECTOR (3 downto 0);
            vga_green : out  STD_LOGIC_VECTOR (3 downto 0);
            vga_hsync : out  STD_LOGIC;    
            vga_vsync : out  STD_LOGIC);          
	end component;

begin
	dut: top_vhdl

        port map (
            clk_in => clk_in,
            reset => reset,
            reset_clk => reset,
           add_filter => add_filter,
            fifo_almost_empty_reg => fifo_almost_empty,
            fifo_almost_full_reg => fifo_almost_full,
            vga_red => vga_red,
            vga_blue => vga_blue, 
            vga_green => vga_green,
            vga_hsync => vga_hsync,
            vga_vsync => vga_vsync
		
        );
	--Simulation du signal d'horloge en continue
	process
    begin
		wait for hp;
		clk_in <= not clk_in;
	end process;
	process
    begin
        reset <= '1';
        wait for 1us;
        reset <= '0';
        wait for 5 us;
        
        add_filter <= '0';

        wait for 20ms;
        add_filter <= '1';

        wait;
	end process;    
end Behavioral;
