library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity top_vhdl is
    generic (
        DATA_WIDTH : integer := 24
    );  
    port(
        clk_in         : in std_logic;
        reset      : in std_logic;
        reset_clk  : in std_logic;
        add_filter  : in std_logic;
        --harris_level : in STD_LOGIC_VECTOR(31 downto 0);
        --max_harris   : out std_logic_vector (31 downto 0);
        --max_harris_x  : out std_logic_vector (31 downto 0);
        --max_harris_y: out std_logic_vector (31 downto 0);
        fifo_almost_empty_reg : out STD_LOGIC;
        fifo_almost_full_reg : out STD_LOGIC;

        vga_hsync   : out std_logic;
        vga_vsync   : out std_logic;
        vga_red     : out std_logic_vector (3 downto 0);
        vga_green   : out std_logic_vector (3 downto 0);   
        vga_blue    : out std_logic_vector (3 downto 0)
    );
end entity top_vhdl;

architecture rtl of top_vhdl is
    signal resetn : std_logic;
    signal clk : std_logic;
    signal pll_locked : std_logic;
    signal gene1_tdata  : std_logic_vector (23 downto 0);
    signal gene1_tvalid : std_logic; 
    signal gene1_tready : std_logic;
    signal gene1_tlast  : std_logic;
    signal gene1_tuser  : std_logic;
    signal gene2_tdata  : std_logic_vector (23 downto 0);
    signal gene2_tvalid : std_logic; 
    signal gene2_tready : std_logic;
    signal gene2_tlast  : std_logic;
    signal gene2_tuser  : std_logic;
    signal gene_broad_tdata  : std_logic_vector (23 downto 0);
    signal gene_broad_tvalid : std_logic; 
    signal gene_broad_tready : std_logic;
    signal gene_broad_tlast  : std_logic;
    signal gene_broad_tuser  : std_logic;
    signal grey_gauss_tdata  : std_logic_vector (23 downto 0);
    signal grey_gauss_tvalid : std_logic; 
    signal grey_gauss_tready : std_logic;
    signal grey_gauss_tlast  : std_logic;
    signal grey_gauss_tuser  : std_logic;
    signal gauss_harris_tdata  : std_logic_vector (23 downto 0);
    signal gauss_harris_tvalid : std_logic; 
    signal gauss_harris_tready : std_logic;
    signal gauss_harris_tlast  : std_logic;
    signal gauss_harris_tuser  : std_logic;
    signal harris_level : STD_LOGIC_VECTOR(9 downto 0) := std_logic_vector(to_unsigned(20, 10));
    signal filter_overlay_tdata  : std_logic_vector (23 downto 0);
    signal filter_overlay_tvalid : std_logic;
    signal filter_overlay_tready : std_logic;
    signal filter_overlay_tlast  : std_logic;
    signal filter_overlay_tuser  : std_logic;
    signal broadcaster_o_tvalid : STD_LOGIC_VECTOR(1 DOWNTO 0);
    signal broadcaster_o_tready : STD_LOGIC_VECTOR(1 DOWNTO 0);
    signal broadcaster_o_tdata : STD_LOGIC_VECTOR(47 DOWNTO 0);
    signal broadcaster_o_tlast : STD_LOGIC_VECTOR(1 DOWNTO 0);
    signal broadcaster_o_tuser : STD_LOGIC_VECTOR(1 DOWNTO 0);
   
    signal fifo_overlay_tdata  : std_logic_vector (23 downto 0);
    signal fifo_overlay_tvalid : std_logic;
    signal fifo_overlay_tready : std_logic;
    signal fifo_overlay_tlast  : std_logic;
    signal fifo_overlay_tuser  : std_logic;
    signal        fifo_axis_wr_data_count : STD_LOGIC_VECTOR(31 DOWNTO 0);
    signal    fifo_axis_rd_data_count : STD_LOGIC_VECTOR(31 DOWNTO 0);
    signal    fifo_almost_empty : STD_LOGIC;
    signal    fifo_almost_full : STD_LOGIC;
    -- signal    fifo_almost_empty_reg : STD_LOGIC;
    --signal    fifo_almost_full_reg : STD_LOGIC;
   signal test : std_logic ;
    signal overlay_vga_tdata  : std_logic_vector (23 downto 0);
    signal overlay_vga_tvalid : std_logic;
    signal overlay_vga_tready : std_logic;
    signal overlay_vga_tlast  : std_logic;
    signal overlay_vga_tuser  : std_logic;

    compone axi4s_mux  is
    generic (
        DATA_WIDTH : integer := 24
    );
    Port (
        clk          : in  STD_LOGIC;
        resetn       : in  STD_LOGIC;
        -- selecteur de flux
        input_sel          : in  STD_LOGIC;
        -- AXI4-Stream input 0
        axi4s_i1_tdata  : in STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
        axi4s_i1_tvalid : in STD_LOGIC;
        axi4s_i1_tready : out  STD_LOGIC;
        axi4s_i1_tlast  : in STD_LOGIC;
        axi4s_i1_tuser  : in STD_LOGIC;
       -- AXI4-Stream input 1
        axi4s_i2_tdata  : in STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
        axi4s_i2_tvalid : in STD_LOGIC;
        axi4s_i2_tready : out  STD_LOGIC;
        axi4s_i2_tlast  : in STD_LOGIC;
        axi4s_i2_tuser  : in STD_LOGIC;
        -- AXI4-Stream Video output
        axi4s_o_tdata  : out STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
        axi4s_o_tvalid : out STD_LOGIC;
        axi4s_o_tready : in  STD_LOGIC;
        axi4s_o_tlast  : out STD_LOGIC;
        axi4s_o_tuser  : out STD_LOGIC
        );
end axi4s_mux;
    COMPONENT axis_broadcaster_1to2
    PORT (
        aclk : IN STD_LOGIC;
        aresetn : IN STD_LOGIC;
        s_axis_tvalid : IN STD_LOGIC;
        s_axis_tready : OUT STD_LOGIC;
        s_axis_tdata : IN STD_LOGIC_VECTOR(23 DOWNTO 0);
        s_axis_tlast : IN STD_LOGIC;
        s_axis_tuser : IN STD_LOGIC_VECTOR(0 DOWNTO 0);
        m_axis_tvalid : OUT STD_LOGIC_VECTOR(1 DOWNTO 0);
        m_axis_tready : IN STD_LOGIC_VECTOR(1 DOWNTO 0);
        m_axis_tdata : OUT STD_LOGIC_VECTOR(47 DOWNTO 0);
        m_axis_tlast : OUT STD_LOGIC_VECTOR(1 DOWNTO 0);
        m_axis_tuser : OUT STD_LOGIC_VECTOR(1 DOWNTO 0)
    );
    END COMPONENT;
    COMPONENT axis_data_fifo_0
    PORT (
        s_axis_aresetn : IN STD_LOGIC;
        s_axis_aclk : IN STD_LOGIC;
        s_axis_tvalid : IN STD_LOGIC;
        s_axis_tready : OUT STD_LOGIC;
        s_axis_tdata : IN STD_LOGIC_VECTOR(23 DOWNTO 0);
        s_axis_tlast : IN STD_LOGIC;
        s_axis_tuser : IN STD_LOGIC_VECTOR(0 DOWNTO 0);
        m_axis_tvalid : OUT STD_LOGIC;
        m_axis_tready : IN STD_LOGIC;
        m_axis_tdata : OUT STD_LOGIC_VECTOR(23 DOWNTO 0);
        m_axis_tlast : OUT STD_LOGIC;
        m_axis_tuser : OUT STD_LOGIC_VECTOR(0 DOWNTO 0);
        axis_wr_data_count : OUT STD_LOGIC_VECTOR(31 DOWNTO 0);
        axis_rd_data_count : OUT STD_LOGIC_VECTOR(31 DOWNTO 0);
        almost_empty : OUT STD_LOGIC;
        almost_full : OUT STD_LOGIC
    );
    END COMPONENT;
    component axi4s_overlay is
        generic (
            DATA_WIDTH : integer := 24
        );
        Port (
            clk          : in  STD_LOGIC;
            resetn       : in  STD_LOGIC;
            -- selecteur de flux
            add_filter          : in  STD_LOGIC;
            -- AXI4-Stream input 0 : filter
            axi4s_i1_tdata  : in STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_i1_tvalid : in STD_LOGIC;
            axi4s_i1_tready : out  STD_LOGIC;
            axi4s_i1_tlast  : in STD_LOGIC;
            axi4s_i1_tuser  : in STD_LOGIC;
        -- AXI4-Stream input 1 : direct
            axi4s_i2_tdata  : in STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_i2_tvalid : in STD_LOGIC;
            axi4s_i2_tready : out  STD_LOGIC;
            axi4s_i2_tlast  : in STD_LOGIC;
            axi4s_i2_tuser  : in STD_LOGIC;
            -- AXI4-Stream Video output
            axi4s_o_tdata  : out STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_o_tvalid : out STD_LOGIC;
            axi4s_o_tready : in  STD_LOGIC;
            axi4s_o_tlast  : out STD_LOGIC;
            axi4s_o_tuser  : out STD_LOGIC
            );
    end component;
    component filter_harris  is
        generic (
            DATA_WIDTH : integer := 24;
            COLOR_WIDTH : integer :=8
        );
        Port (
            clk          : in  STD_LOGIC;
            resetn       : in  STD_LOGIC;
            harris_level : in STD_LOGIC_VECTOR(9 downto 0);
            max_harris   : out std_logic_vector (10 downto 0);
            max_harris_x  : out std_logic_vector (9 downto 0);
            max_harris_y: out std_logic_vector (9 downto 0);
            -- AXI4-Stream Video input
            axi4s_i_tdata  : in STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_i_tvalid : in STD_LOGIC;
            axi4s_i_tready : out  STD_LOGIC;
            axi4s_i_tlast  : in STD_LOGIC;
            axi4s_i_tuser  : in STD_LOGIC;
            -- AXI4-Stream Video output
            axi4s_o_tdata  : out STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_o_tvalid : out STD_LOGIC;
            axi4s_o_tready : in  STD_LOGIC;
            axi4s_o_tlast  : out STD_LOGIC;
            axi4s_o_tuser  : out STD_LOGIC
            );
    end component;
    component filter_gauss  is
        generic (
            DATA_WIDTH : integer := 24;
            COLOR_WIDTH : integer :=8
        );
        Port (
            clk          : in  STD_LOGIC;
            resetn       : in  STD_LOGIC;
            -- AXI4-Stream Video input
            axi4s_i_tdata  : in STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_i_tvalid : in STD_LOGIC;
            axi4s_i_tready : out  STD_LOGIC;
            axi4s_i_tlast  : in STD_LOGIC;
            axi4s_i_tuser  : in STD_LOGIC;
            -- AXI4-Stream Video output
            axi4s_o_tdata  : out STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_o_tvalid : out STD_LOGIC;
            axi4s_o_tready : in  STD_LOGIC;
            axi4s_o_tlast  : out STD_LOGIC;
            axi4s_o_tuser  : out STD_LOGIC
            );
    end component;    
	component filter_grey
        generic (
            DATA_WIDTH : integer := 24;
            COLOR_WIDTH : integer :=8
        );
        port (
            clk          : in  STD_LOGIC;
            resetn       : in  STD_LOGIC;
            -- AXI4-Stream Video input
            axi4s_i_tdata  : in STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_i_tvalid : in STD_LOGIC;
            axi4s_i_tready : out  STD_LOGIC;
            axi4s_i_tlast  : in STD_LOGIC;
            axi4s_i_tuser  : in STD_LOGIC;
            -- AXI4-Stream Video output
            axi4s_o_tdata  : out STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_o_tvalid : out STD_LOGIC;
            axi4s_o_tready : in  STD_LOGIC;
            axi4s_o_tlast  : out STD_LOGIC;
            axi4s_o_tuser  : out STD_LOGIC
        );

	end component;
    component pattern_generator
        generic (
            DATA_WIDTH : integer := 24
        );
        port (
            clk          : in  STD_LOGIC;
            resetn       : in  STD_LOGIC;
            pattern_en   : in STD_LOGIC;
            -- AXI4-Stream Video
            axi4s_tdata  : out STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_tvalid : out STD_LOGIC;
            axi4s_tready : in  STD_LOGIC;
            axi4s_tlast  : out STD_LOGIC;
            axi4s_tuser  : out STD_LOGIC
        );
    end component;
    component axi4s_to_vga
        generic (
            DATA_WIDTH : integer := 24
        );
        port (
            clk          : in  STD_LOGIC;
            resetn       : in  STD_LOGIC;
            -- AXI4-Stream Video input
            axi4s_tdata  : in STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
            axi4s_tvalid : in STD_LOGIC;
            axi4s_tready : out  STD_LOGIC;
            axi4s_tlast  : in STD_LOGIC;
            axi4s_tuser  : in STD_LOGIC;
            -- VGA output
            vga_hsync    : out STD_LOGIC;
            vga_vsync    : out STD_LOGIC;
            vga_red      : out STD_LOGIC_VECTOR(3 downto 0);
            vga_green    : out STD_LOGIC_VECTOR(3 downto 0);   
            vga_blue     : out STD_LOGIC_VECTOR(3 downto 0)
        );
    end component;  
    component clk_wiz_0
        port (
        clk_out1          : out    std_logic;
        reset             : in     std_logic;
        locked            : out    std_logic;
        clk_in1           : in     std_logic
        );
    end component;

    
begin
    resetn <= not reset;
    u_clk_wiz_0 : clk_wiz_0
        port map (
            clk_out1 => clk,
            reset    => reset_clk,
            locked   => pll_locked,
            clk_in1  => clk_in
        );
    u_pattern_generator : pattern_generator
        port map (
            clk          => clk,
            resetn       => resetn,
            pattern_en   => pll_locked,
            axi4s_tdata  => gene_broad_tdata,
            axi4s_tvalid => gene_broad_tvalid,
            axi4s_tready => gene_broad_tready,
            axi4s_tlast  => gene_broad_tlast,
            axi4s_tuser  => gene_broad_tuser
        );

    u_broascaster : axis_broadcaster_1to2
        PORT MAP (
            aclk => clk,
            aresetn => resetn,
            s_axis_tvalid => gene_broad_tvalid,
            s_axis_tready => gene_broad_tready,
            s_axis_tdata => gene_broad_tdata,
            s_axis_tlast => gene_broad_tlast,
            s_axis_tuser(0) => gene_broad_tuser,
            m_axis_tvalid => broadcaster_o_tvalid,
            m_axis_tready => broadcaster_o_tready,
            m_axis_tdata => broadcaster_o_tdata,
            m_axis_tlast => broadcaster_o_tlast,
            m_axis_tuser => broadcaster_o_tuser
        );
    u_fifo : axis_data_fifo_0
    PORT MAP (
        s_axis_aresetn => resetn,
        s_axis_aclk => clk,
        s_axis_tvalid => broadcaster_o_tvalid(0),
        s_axis_tready => broadcaster_o_tready(0),
        s_axis_tdata => broadcaster_o_tdata(23 downto 0),
        s_axis_tlast => broadcaster_o_tlast(0),
        s_axis_tuser(0) => broadcaster_o_tuser(0),
        m_axis_tvalid => fifo_overlay_tvalid,
        m_axis_tready => fifo_overlay_tready,
        m_axis_tdata => fifo_overlay_tdata,
        m_axis_tlast => fifo_overlay_tlast,
        m_axis_tuser(0) => fifo_overlay_tuser,
        axis_wr_data_count => fifo_axis_wr_data_count,
        axis_rd_data_count => fifo_axis_rd_data_count,
        almost_empty => fifo_almost_empty,
        almost_full => fifo_almost_full
    );
     
	u_filter_grey : filter_grey
        port map (
            clk          => clk,
            resetn       => resetn,
            axi4s_i_tdata  => broadcaster_o_tdata(47 downto 24),
            axi4s_i_tvalid => broadcaster_o_tvalid(1),
            axi4s_i_tready => broadcaster_o_tready(1),
            axi4s_i_tlast  => broadcaster_o_tlast(1),
            axi4s_i_tuser  => broadcaster_o_tuser(1),
            axi4s_o_tdata  => grey_gauss_tdata,
            axi4s_o_tvalid => grey_gauss_tvalid,
            axi4s_o_tready => grey_gauss_tready,
            axi4s_o_tlast  => grey_gauss_tlast,
            axi4s_o_tuser  => grey_gauss_tuser
        );
	u_filter_gauss : filter_gauss
        port map (
            clk          => clk,
            resetn       => resetn,
            axi4s_i_tdata  => grey_gauss_tdata,
            axi4s_i_tvalid => grey_gauss_tvalid,
            axi4s_i_tready => grey_gauss_tready,
            axi4s_i_tlast  => grey_gauss_tlast,
            axi4s_i_tuser  => grey_gauss_tuser,
            axi4s_o_tdata  => gauss_harris_tdata,
            axi4s_o_tvalid => gauss_harris_tvalid,
            axi4s_o_tready => gauss_harris_tready,
            axi4s_o_tlast  => gauss_harris_tlast,
            axi4s_o_tuser  => gauss_harris_tuser

       );
	u_filter_harris : filter_harris
        port map (
            clk          => clk,
            resetn       => resetn,
            harris_level =>harris_level,
            max_harris   =>open,
            max_harris_x  =>open,
            max_harris_y=>open,
            axi4s_i_tdata  => gauss_harris_tdata,
            axi4s_i_tvalid => gauss_harris_tvalid,
            axi4s_i_tready => gauss_harris_tready,
            axi4s_i_tlast  => gauss_harris_tlast,
            axi4s_i_tuser  => gauss_harris_tuser,
            axi4s_o_tdata  => filter_overlay_tdata,
            axi4s_o_tvalid => filter_overlay_tvalid,
            axi4s_o_tready => filter_overlay_tready,
            axi4s_o_tlast  => filter_overlay_tlast,
            axi4s_o_tuser  => filter_overlay_tuser

       );
	u_overlay : axi4s_overlay
        port map (
            clk          => clk,
            resetn       => resetn,
            add_filter => add_filter,
            axi4s_i1_tdata  => filter_overlay_tdata,
            axi4s_i1_tvalid => filter_overlay_tvalid,
            axi4s_i1_tready => filter_overlay_tready,
            axi4s_i1_tlast  => filter_overlay_tlast,
            axi4s_i1_tuser  => filter_overlay_tuser,
            axi4s_i2_tdata  => fifo_overlay_tdata,
            axi4s_i2_tvalid => fifo_overlay_tvalid,
            axi4s_i2_tready => fifo_overlay_tready,
            axi4s_i2_tlast  => fifo_overlay_tlast,
            axi4s_i2_tuser  => fifo_overlay_tuser,
            axi4s_o_tdata  => overlay_vga_tdata,
            axi4s_o_tvalid => overlay_vga_tvalid,
            axi4s_o_tready => overlay_vga_tready,
            axi4s_o_tlast  => overlay_vga_tlast,
            axi4s_o_tuser  => overlay_vga_tuser

            );



    u_axi4s_to_vga : axi4s_to_vga
            port map(
            clk          => clk,    
            resetn       => resetn,
            axi4s_tdata  => overlay_vga_tdata,
            axi4s_tvalid => overlay_vga_tvalid,
            axi4s_tready => overlay_vga_tready,
            axi4s_tlast  => overlay_vga_tlast,
            axi4s_tuser  => overlay_vga_tuser,
            vga_hsync    => vga_hsync,  
            vga_vsync    => vga_vsync,
            vga_red      => vga_red,
            vga_green    => vga_green,   
            vga_blue     => vga_blue        
        );
    -- ajout registre pour debug
    fifo_reg : process(clk, resetn)
    begin
        if resetn = '0' then
            fifo_almost_empty_reg <= '0';
            fifo_almost_full_reg <= '0';
        elsif rising_edge (clk) then 
            fifo_almost_empty_reg <= fifo_almost_empty;
            fifo_almost_full_reg <= fifo_almost_full;  

               
        end if ;
     
    end process; 

   

    end architecture rtl;
