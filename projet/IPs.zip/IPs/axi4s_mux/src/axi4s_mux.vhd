-- modif history
-- 1.1 remove condition on tuser for changing signal

library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;


entity axi4s_mux  is
    generic (
        DATA_WIDTH : integer := 24
    );
    Port (
        clk          : in  STD_LOGIC;
        resetn       : in  STD_LOGIC;
        -- selecteur de flux
        input_sel          : in  STD_LOGIC;
        -- AXI4-Stream input 0
        axi4s_i1_tdata  : in STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
        axi4s_i1_tvalid : in STD_LOGIC;
        axi4s_i1_tready : out  STD_LOGIC;
        axi4s_i1_tlast  : in STD_LOGIC;
        axi4s_i1_tuser  : in STD_LOGIC;
       -- AXI4-Stream input 1
        axi4s_i2_tdata  : in STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
        axi4s_i2_tvalid : in STD_LOGIC;
        axi4s_i2_tready : out  STD_LOGIC;
        axi4s_i2_tlast  : in STD_LOGIC;
        axi4s_i2_tuser  : in STD_LOGIC;
        -- AXI4-Stream Video output
        axi4s_o_tdata  : out STD_LOGIC_VECTOR(DATA_WIDTH-1 downto 0);
        axi4s_o_tvalid : out STD_LOGIC;
        axi4s_o_tready : in  STD_LOGIC;
        axi4s_o_tlast  : out STD_LOGIC;
        axi4s_o_tuser  : out STD_LOGIC
        );
end axi4s_mux;

architecture Behavioral of axi4s_mux is
begin
    axi4s_i1_tready <= axi4s_o_tready when input_sel = '0' else '0';
    axi4s_i2_tready <= axi4s_o_tready when input_sel = '1' else '0';

    -- Donn�es
    axi4s_o_tdata <= axi4s_i1_tdata when input_sel = '0'
                     else axi4s_i2_tdata;

    -- TVALID
    axi4s_o_tvalid <= axi4s_i1_tvalid when input_sel = '0'
                      else axi4s_i2_tvalid;

    -- TLAST
    axi4s_o_tlast <= axi4s_i1_tlast when input_sel = '0'
                     else axi4s_i2_tlast;

    -- TUSER
    axi4s_o_tuser <= axi4s_i1_tuser when input_sel= '0'
                     else axi4s_i2_tuser;

end Behavioral;
