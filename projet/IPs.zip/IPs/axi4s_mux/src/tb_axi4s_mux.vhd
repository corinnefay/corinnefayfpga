library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity tb_axi4s_mux is
end tb_axi4s_mux;

architecture behavioral of tb_axi4s_mux is

	constant data_width_c : integer := 8;      --taille du bus de donnee pour chaque couleur 
	constant data_width : integer := 8;      --taille du bus de donnee de l'axi4s	
    signal resetn      : std_logic := '1';
	signal reset       : std_logic := '0';
	signal clk         : std_logic := '0';
    signal axi4s_i1_tdata : STD_LOGIC_VECTOR (data_width-1 downto 0);
    signal axi4s_i1_tvalid : STD_LOGIC;
    signal axi4s_i1_tready : STD_LOGIC;
    signal axi4s_i1_tlast : STD_LOGIC;
    signal axi4s_i1_tuser : STD_LOGIC;
    signal axi4s_i2_tdata : STD_LOGIC_VECTOR (data_width-1 downto 0);
    signal axi4s_i2_tvalid : STD_LOGIC;
    signal axi4s_i2_tready : STD_LOGIC;
    signal axi4s_i2_tlast : STD_LOGIC;
    signal axi4s_i2_tuser : STD_LOGIC;
    signal axi4s_o_tdata : STD_LOGIC_VECTOR (data_width-1 downto 0);
    signal axi4s_o_tvalid : STD_LOGIC;
    signal axi4s_o_tready : STD_LOGIC;
    signal axi4s_o_tlast : STD_LOGIC;
    signal axi4s_o_tuser : STD_LOGIC;
    signal done : std_logic;
    signal img_cnt : integer;
    signal line_cnt : integer;
    signal pixel_cnt : integer;
    signal filter_sel : std_logic;
 
    -- Les constantes suivantes permette de definir la frequence de l'horloge 
	constant hp : time := 20ns;      --demi periode de 20ns
	constant period : time := 2 * hp;  --periode de 40ns, soit une frequence de 25MHz
		
	component axi4s_mux is
	Generic( DATA_WIDTH        : integer := data_width
      );
    Port ( clk : in STD_LOGIC;
           resetn : in STD_LOGIC;
           input_sel          : in  STD_LOGIC;
           axi4s_i1_tdata : in STD_LOGIC_VECTOR (data_width-1 downto 0);
           axi4s_i1_tvalid : in STD_LOGIC;
           axi4s_i1_tready : out STD_LOGIC;
           axi4s_i1_tlast : in STD_LOGIC;
           axi4s_i1_tuser : in STD_LOGIC;
           axi4s_i2_tdata : in STD_LOGIC_VECTOR (data_width-1 downto 0);
           axi4s_i2_tvalid : in STD_LOGIC;
           axi4s_i2_tready : out STD_LOGIC;
           axi4s_i2_tlast : in STD_LOGIC;
           axi4s_i2_tuser : in STD_LOGIC;
           axi4s_o_tdata : out STD_LOGIC_VECTOR (data_width-1 downto 0);
           axi4s_o_tvalid : out STD_LOGIC;
           axi4s_o_tready : in STD_LOGIC;
           axi4s_o_tlast : out STD_LOGIC;
           axi4s_o_tuser : out STD_LOGIC);
    end component;       
	component axi4s_driver is
        generic (
            G_FILE_PATH         : string  := "sample_in_b.txt";
            G_DATA_WIDTH        : integer := data_width_c;
            G_INIT_DELAY        : integer := 0;
            G_TLAST_END_OF_LINE : boolean := true;
            G_LOOP_COUNT        : integer := 0   -- 0 = boucle infinie
        );
        Port ( 
            clk_i : in STD_LOGIC;
            rst_i : in STD_LOGIC;
            m_tvalid : out STD_LOGIC;
            m_tdata : out STD_LOGIC_VECTOR (data_width_c-1 downto 0);
            m_tlast : out STD_LOGIC; 
            m_tready : in STD_LOGIC;
            done_o : out STD_LOGIC;
            frame_cnt_o : out integer;
            pixel_cnt_o : out integer);
        end component;
    component axi4s_monitor is
        generic (
            G_FILE_BASENAME : string  := "stream_r_out";
            G_DATA_WIDTH    : integer := 8;
            G_IMG_WIDTH     : integer := 640;
            G_IMG_HEIGHT    : integer := 480;
            G_NB_IMAGES     : integer := 1;
            G_TIMEOUT_CY    : integer := 10000;
            G_SYNC_ON_SOF   : boolean := false
        );
        port (
            clk_i    : in  std_logic;
            rst_i    : in  std_logic;    -- reset actif haut
            s_tvalid : in  std_logic;
            s_tdata  : in  std_logic_vector(G_DATA_WIDTH-1 downto 0);
            s_tlast  : in  std_logic;
            s_tuser  : in  std_logic := '0';   -- SOF : '1' sur le premier pixel de trame
            s_tready : out std_logic;
            done_o      : out std_logic;  -- '1' apres capture de toutes les images
            img_cnt_o   : out integer;    -- indice de l'image en cours
            line_cnt_o  : out integer;    -- lignes capturees dans l'image courante
            pixel_cnt_o : out integer     -- pixels totaux captures
        );
        end component;

	begin
	dut: axi4s_mux
        port map (
            clk => clk,
            resetn => resetn,
            input_sel => filter_sel,
            axi4s_i1_tdata => axi4s_i1_tdata,
            axi4s_i1_tvalid => axi4s_i1_tvalid,
            axi4s_i1_tready => axi4s_i1_tready,
            axi4s_i1_tlast => axi4s_i1_tlast,
            axi4s_i1_tuser => axi4s_i1_tuser,
            axi4s_i2_tdata => axi4s_i2_tdata,
            axi4s_i2_tvalid => axi4s_i2_tvalid,
            axi4s_i2_tready => axi4s_i2_tready,
            axi4s_i2_tlast => axi4s_i2_tlast,
            axi4s_i2_tuser => axi4s_i2_tuser,
            axi4s_o_tdata => axi4s_o_tdata,
            axi4s_o_tvalid => axi4s_o_tvalid,
            axi4s_o_tready => axi4s_o_tready,
            axi4s_o_tlast => axi4s_o_tlast,
            axi4s_o_tuser => axi4s_o_tuser
            );  
    axi4s_driver_r : axi4s_driver
        generic map(
            G_FILE_PATH => "sample_in_r.txt"
        )      
        port map (
            clk_i => clk,
            rst_i => reset,
            m_tvalid => axi4s_i1_tvalid,
            m_tdata => axi4s_i1_tdata(data_width-1 downto 0),
            m_tlast => axi4s_i1_tlast, 
            m_tready => axi4s_i1_tready,
            done_o => open,
            frame_cnt_o => open,
            pixel_cnt_o => open
            );
    axi4s_driver_g : axi4s_driver
        generic map(
            G_FILE_PATH => "sample_in_g.txt"
        )        
        port map (
            clk_i => clk,
            rst_i => reset,
            m_tvalid => axi4s_i2_tvalid,
            m_tdata => axi4s_i2_tdata(data_width-1 downto 0),
            m_tlast => axi4s_i2_tlast, 
            m_tready => axi4s_i2_tready,
            done_o => open,
            frame_cnt_o => open,
            pixel_cnt_o => open
            );
	
    axi4s_monitor_r :  axi4s_monitor
        generic map(
            G_FILE_BASENAME => "stream_r_out"
        )
        port map(
            clk_i    => clk,
            rst_i   => reset,  
            s_tvalid => axi4s_o_tvalid,
            s_tdata  => axi4s_o_tdata(data_width-1 downto 0),
            s_tlast  => axi4s_o_tlast,
            s_tuser  => axi4s_o_tuser,   
            s_tready => axi4s_o_tready,
            done_o      =>open,  
            img_cnt_o   =>open,  
            line_cnt_o  =>open,   
            pixel_cnt_o =>open   
        );
    axi4s_monitor_g :  axi4s_monitor
        generic map (
            G_FILE_BASENAME => "stream_g_out"
        )
        port map(
            clk_i    => clk,
            rst_i   => reset,  
            s_tvalid => axi4s_o_tvalid,
            s_tdata  => axi4s_o_tdata(data_width-1 downto 0),
            s_tlast  => axi4s_o_tlast,
            s_tuser  => axi4s_o_tuser,   
            s_tready => axi4s_o_tready,
            done_o      =>done,  
            img_cnt_o   =>open,  
            line_cnt_o  =>open,   
            pixel_cnt_o =>open   
        );

	--Simulation du signal d'horloge en continue
	process
    begin
		wait for hp;
		clk <= not clk;
	end process;

	process
    begin   
        reset <= '1';
        resetn <= '0';
        --axi4s_o_tready <= '0';
        filter_sel <= '0';
        wait for 145ns;
       --axi4s_o_tready <= '0';
        reset <= '0';
        resetn <= '1';   
        wait for 80ns;
        wait for 1ms;
        filter_sel <= '1';
        wait for 1ms;
        filter_sel <= '0';  
        --axi4s_o_tready <= '1';

        wait until rising_edge (done);       
        --wait for 40ns;
    
        wait;
    
	end process;
	
	
end behavioral;