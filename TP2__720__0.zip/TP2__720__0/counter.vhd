library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

entity counter_unit is
    port ( 
		clk			: in std_logic; 
        reset		: in std_logic; 
        restart		: in std_logic; 
        end_counter	: out std_logic    
     );
end counter_unit;

architecture behavioral of counter_unit is
	--Declaration des signaux internes
    constant cible : positive := 200000000;
	signal d_counter	: std_logic_vector ( 27 downto 0) := (others => '0');
	signal q_counter	: std_logic_vector ( 27 downto 0):= (others => '0');
	signal end_counter_internal: std_logic := '0';
	signal comp : std_logic := '0';
	signal comp_old : std_logic := '0';

	begin
		--Partie sequentielle
		process(clk,reset)
		begin
		     -- reset instead if resetn due to btn connection always low 
			if (reset = '1') then 
				q_counter <=(others => '0');
				end_counter_internal <= '0';
			elsif (restart = '1') then 
			 	q_counter <=(others => '0');
				end_counter_internal <= '0';
		 	elsif(rising_edge(clk)) then
                comp_old <= comp;
                q_counter <= d_counter;
                -- rising edge sur comp
                 if ((comp = '1') and (comp_old = '0')) then 
                      end_counter_internal <= not end_counter_internal;
                      q_counter <=(others => '0');
                  end if;
			end if;
		end process;
		--Partie combinatoire
		comp <= '1' when to_integer(unsigned(d_counter)) >= cible
				else '0';
		d_counter <= q_counter + 1;
		end_counter <= end_counter_internal;  
end behavioral;