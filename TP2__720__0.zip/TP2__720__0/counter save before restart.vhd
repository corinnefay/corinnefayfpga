library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;

entity counter_unit is
    port ( 
		clk			: in std_logic; 
        resetn		: in std_logic; 
        end_counter	: out std_logic    
     );
end counter_unit;

architecture behavioral of counter_unit is
	--Declaration des signaux internes
    constant cible : positive := 2000;
	signal d_counter	: std_logic_vector ( 27 downto 0) := (others => '0');
	signal q_counter	: std_logic_vector ( 27 downto 0):= (others => '0');
	signal resetn_counter: std_logic := '0';
	
	begin
		--Partie sequentielle
		process(clk,resetn)
		begin
			if ((resetn = '0') or (resetn_counter = '0')) then 
				q_counter <=(others => '0');
			elsif(rising_edge(clk)) then
				q_counter <= d_counter;
			end if;
		end process;
		--Partie combinatoire
		end_counter <= '1' when to_integer(unsigned(q_counter)) >= cible
				else '0';
		d_counter <= q_counter + 1;
		resetn_counter <= '0' when to_integer(unsigned(q_counter)) >= cible
		  else '1';
end behavioral;