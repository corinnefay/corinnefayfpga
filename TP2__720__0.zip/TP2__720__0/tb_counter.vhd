library ieee;
use ieee.std_logic_1164.all;

entity tb_counter is
end tb_counter;

architecture behavioral of tb_counter is

	signal clk         : std_logic := '0';
	signal restart        : std_logic := '0';
	signal reset        : std_logic := '1';
	signal end_counter : std_logic := '0';

	-- Les constantes suivantes permette de defsinir la frequence de l'horloge 
	constant hp : time := 5 ns;      --demi periode de 5ns
	constant period : time := 2*hp;  --periode de 10ns, soit une frequence de 100Hz
	
	--Declaration de l'entite a tester
	component counter_unit 
		port ( 
			clk			: in std_logic; 
			reset       : in std_logic;
			restart     : in std_logic;
			end_counter	: out std_logic 
		 );
	end component;
	
	

	begin
	
	--Affectation des signaux du testbench avec ceux de l'entite a tester
	uut: counter_unit
        port map (
            clk => clk,
            restart => restart, 
            reset => reset,
            end_counter => end_counter
        );
		
	--Simulation du signal d'horloge en continue
	process
    begin
		wait for hp;
		clk <= not clk;
	end process;


	process
	begin   
	   -- test bench pour cible = 20   
	   wait for 50ns;
	   reset <='1';
	   wait for 25ns;	   
	   assert end_counter = '1' 
	       report " test reset OK" severity note;
	   wait for 25ns;  
	   reset <='0';
	   wait for 210ns;	   
	   assert end_counter = '0'  
	       report "OK comptage termin� apres reset"  severity note;
	   wait for 50ns;
	   restart <='1';
	   wait for 25ns;	   
	   assert end_counter = '1'
	       report "OK test restart OK" severity note;
	   wait for 25ns;  
	   restart <='0';
	   wait for 210ns;	   
	   assert end_counter = '0'
	       report "OK comptage termin� apres restart"  severity note;
	   wait for 210ns;	   
	   assert end_counter = '1'
	       report "OK comptage termin� alternance end_counter OK "  severity note;
	   wait for 400ns;
	   wait;


	end process;
	
	
end behavioral;